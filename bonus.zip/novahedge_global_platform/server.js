/**
 * NovaHedge Global — FinTech Investor & Hedging Platform Server
 * Zero-dependency Node.js server with REST APIs and MT5 Telemetry Ingestion.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 4000;

// Persistent In-Memory Datastore
const db = {
  wallet: {
    balance: 42.25,
    rate_usd: 17745,
    total_topup: 1500.00,
    fee_profit: 134.11,
    biaya_vps: 0.00,
    profit_kumulatif: 0.00,
    hwm: 0.00,
    pool_profit_net: 311.58,
    active_deposit: 1719.73,
    withdrawals: [
      { id: 1, amount: 72.00, date: "22 Agu, 15.01", status: "disetujui" }
    ]
  },
  pools: [
    {
      id: "pool_b",
      name: "Pool B",
      porsi: "2.23%",
      deposit: 222.60,
      status: "ACTIVE",
      cycle_start: "14.29",
      distribusi: 6.22,
      closings_count: 8,
      auto_roll: false
    },
    {
      id: "pool_a",
      name: "Pool A",
      porsi: "14.97%",
      deposit: 1497.13,
      status: "ACTIVE",
      cycle_start: "11.28",
      distribusi: 305.36,
      closings_count: 28,
      auto_roll: false
    }
  ],
  journal: [
    { id: 453, date: "25 Agu, 06.50", profit_pool: 2.73, share: "2.24%", fee: 0.00, net: 0.06, kumulatif: 311.58 },
    { id: 450, date: "25 Agu, 05.59", profit_pool: -62.55, share: "2.24%", fee: 0.00, net: -1.40, kumulatif: 311.52 },
    { id: 446, date: "24 Agu, 20.47", profit_pool: 32.70, share: "15%", fee: -1.47, net: 3.43, kumulatif: 312.92 },
    { id: 442, date: "24 Agu, 18.38", profit_pool: 44.19, share: "2.24%", fee: -0.30, net: 0.69, kumulatif: 309.49 },
    { id: 441, date: "24 Agu, 18.38", profit_pool: 49.14, share: "15%", fee: -2.21, net: 5.16, kumulatif: 308.80 }
  ],
  referral: {
    code: "9XTVX2",
    link: "https://novahedge.global/?ref=9XTVX2",
    commission_rate: "33.3%",
    omzet_total: 8300.00,
    downlines_count: 5,
    downlines: [
      { name: "Hermawan Lesmana", date: "06 Agu 2026", commission: 16.09, commission_rp: 285522 },
      { name: "BARRY HII CHAY WEE", date: "26 Agu 2026", commission: 0.00, commission_rp: 0 },
      { name: "Nadiyah Khairunnisa", date: "26 Agu 2026", commission: 0.00, commission_rp: 0 },
      { name: "Yeoh Kok Wooi", date: "26 Agu 2026", commission: 6.31, commission_rp: 111973 },
      { name: "Nadiyah Khairunnisa", date: "27 Agu 2026", commission: 0.00, commission_rp: 0 }
    ]
  },
  mt5_live: {
    rate: 17.745,
    bid_ask: "4579.07/4579.35",
    master: { equity: 8515.62, balance: 4690.32, credit: 0.00, mc_price: 4648.19, mc_pips: 69.1, margin_level: 769.47 },
    slave: { equity: 2244.99, balance: 5500.00, credit: 1100.00, mc_price: 4563.91, mc_pips: -15.2, margin_level: 184.38 },
    positions: [
      {
        master_ticket: 13521243, master_vol: 0.3, master_price: 4641.55, master_prof: 1866.00,
        slave_ticket: 13521244, slave_vol: 0.33, slave_price: 4641.82, slave_prof: -2070.75,
        net_prof: -204.75
      },
      {
        master_ticket: 13531234, master_vol: 0.3, master_price: 4621.59, master_prof: 1267.20,
        slave_ticket: 13531235, slave_vol: 0.33, slave_price: 4621.84, slave_prof: -1411.41,
        net_prof: -144.21
      }
    ]
  }
};

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  // 1. INGEST MT5 TELEMETRY
  if (req.method === 'POST' && pathname === '/api/mt5/telemetry') {
    let body = '';
    req.on('data', chunk => body += chunk.toString());
    req.on('end', () => {
      try {
        const payload = JSON.parse(body);
        db.mt5_live.master.equity = payload.master?.equity || db.mt5_live.master.equity;
        db.mt5_live.master.balance = payload.master?.balance || db.mt5_live.master.balance;
        db.mt5_live.master.margin_level = payload.master?.margin_level || db.mt5_live.master.margin_level;

        db.mt5_live.slave.equity = payload.slave?.equity || db.mt5_live.slave.equity;
        db.mt5_live.slave.balance = payload.slave?.balance || db.mt5_live.slave.balance;
        db.mt5_live.slave.margin_level = payload.slave?.margin_level || db.mt5_live.slave.margin_level;

        if (payload.pairs) {
          db.mt5_live.positions = payload.pairs;
        }

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, timestamp: Date.now() }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  // 2. GET LIVE MT5 DATA
  if (req.method === 'GET' && pathname === '/api/mt5/live') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(db.mt5_live));
    return;
  }

  // 3. GET WALLET DATA
  if (req.method === 'GET' && pathname === '/api/wallet') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(db.wallet));
    return;
  }

  // 4. GET POOLS DATA
  if (req.method === 'GET' && pathname === '/api/pools') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(db.pools));
    return;
  }

  // 5. GET JOURNAL DATA
  if (req.method === 'GET' && pathname === '/api/journal') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(db.journal));
    return;
  }

  // 6. GET REFERRAL DATA
  if (req.method === 'GET' && pathname === '/api/referral') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(db.referral));
    return;
  }

  // 7. SERVE STATIC FRONTEND
  if (req.method === 'GET') {
    const publicDir = path.join(__dirname, 'public');
    let filePath = path.join(publicDir, pathname === '/' ? 'index.html' : pathname);

    if (!filePath.startsWith(publicDir)) {
      res.writeHead(403);
      res.end('Forbidden');
      return;
    }

    fs.readFile(filePath, (err, content) => {
      if (err) {
        fs.readFile(path.join(publicDir, 'index.html'), (err2, indexContent) => {
          if (err2) {
            res.writeHead(404);
            res.end('Page Not Found');
          } else {
            res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
            res.end(indexContent);
          }
        });
      } else {
        const ext = path.extname(filePath).toLowerCase();
        const mimeTypes = {
          '.html': 'text/html; charset=utf-8',
          '.css': 'text/css',
          '.js': 'application/javascript',
          '.json': 'application/json',
          '.png': 'image/png'
        };
        res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'text/plain' });
        res.end(content);
      }
    });
    return;
  }

  res.writeHead(404);
  res.end('Not Found');
});

server.listen(PORT, () => {
  console.log('===========================================================');
  console.log(' ⚡ NOVAHEDGE GLOBAL — INVESTOR & HEDGING PLATFORM ACTIVE');
  console.log(` 👉 Server Port       : ${PORT}`);
  console.log(` 👉 Live Web Portal   : http://localhost:${PORT}`);
  console.log('===========================================================');
});
