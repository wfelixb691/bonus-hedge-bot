@echo off
title Telegram Live Reporter - Dual MT5 Bonus Hedging
cd /d "%~dp0"

echo ============================================================
echo   STARTING TELEGRAM LIVE REPORTER...
echo ============================================================
echo.

"C:\Users\Administrator\AppData\Local\Programs\Python\Python38\python.exe" telegram_reporter.py
if %ERRORLEVEL% NEQ 0 (
    python telegram_reporter.py
)
pause
