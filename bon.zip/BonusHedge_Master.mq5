//+------------------------------------------------------------------+
//|                                           BonusHedge_Master.mq5  |
//|                         All-in-One Dual-MT5 Bonus Hedging Master |
//|                                  Copyright 2026, Advanced Bot EA |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Advanced Bot EA"
#property link      "https://www.mql5.com"
#property version   "1.20"
#property strict

#include <Trade\Trade.mqh>

//--- Input Parameters
input group "=== GRID STRATEGY PARAMETERS ==="
input string   InpSymbol            = "XAUUSD";      // Trading Symbol
input double   InpInitialLot        = 0.10;          // Base Lot Size (e.g. 0.10 or 0.30)
input bool     InpAutoScaleLot      = false;         // Auto-Scale Lot by Balance (false = Fixed Lot)
input double   InpGridStepPoints    = 2000.0;        // Grid Step Points ($20.00 on Gold)
input int      InpMaxLayers         = 10;            // Maximum Grid Layers
input double   InpBasketTPDollars   = 31.74;         // Master Basket TP ($ Total)
input ulong    InpMagic             = 888111;        // Master Magic Number
input string   InpCommentPrefix     = "GRID_S";      // Comment Prefix for Layers

input group "=== MARGIN & CIRCUIT BREAKER (CROSS-CHECK) ==="
input double   InpMinMarginLevel    = 50.0;          // Min Margin Level % (Stop opening if below)
input double   InpMinFreeMargin     = 10.0;          // Min Free Margin $ (Stop opening if below)
input bool     InpHarvestOnSlaveMC  = true;          // Auto Close Master if Slave hits Margin Call/StopOut

input group "=== TELEGRAM LIVE REPORT SETTINGS ==="
input bool     InpEnableTelegram       = true;                    // Enable Telegram Live Alerts
input string   InpTelegramBotToken     = "";                      // Telegram Bot Token (from @BotFather)
input string   InpTelegramChatID       = "";                      // Telegram Chat ID (from @userinfobot)
input int      InpTelegramIntervalMin  = 5;                       // Periodic Report Interval (Minutes)

input group "=== BRIDGE & COMM SETTINGS ==="
input string   InpMasterFile        = "bonus_hedge_master.dat";   // Master State File (FILE_COMMON)
input string   InpSlaveFile         = "bonus_hedge_slave.dat";    // Slave State File (FILE_COMMON)
input string   InpCommandFile       = "bonus_hedge_command.dat";  // Command File (FILE_COMMON)
input int      InpTimerMS           = 50;                         // Sync Interval in ms

//--- Global Objects
CTrade         m_trade;
datetime       m_last_order_time    = 0;
datetime       m_last_telegram_time = 0;
string         m_symbol             = "";
double         m_point              = 0.01;
int            m_digits             = 2;
bool           m_closing_active     = false;


// Slave Telemetry Snapshot
struct SlavePosInfo
{
   ulong  ticket;
   int    type;
   double volume;
   double price_open;
   double profit;
   string comment;
};

SlavePosInfo   m_slave_positions[];
long           m_slave_time         = 0;
long           m_slave_login        = 0;
double         m_slave_equity       = 0.0;
double         m_slave_balance      = 0.0;
double         m_slave_free_margin  = 0.0;
double         m_slave_margin_level = 0.0;
double         m_slave_profit       = 0.0;
int            m_slave_pos_count    = 0;
bool           m_slave_online       = false;

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
   m_symbol = (InpSymbol == "" || InpSymbol == "0") ? _Symbol : InpSymbol;
   if(!SymbolSelect(m_symbol, true)) m_symbol = _Symbol;

   m_point  = SymbolInfoDouble(m_symbol, SYMBOL_POINT);
   m_digits = (int)SymbolInfoInteger(m_symbol, SYMBOL_DIGITS);
   if(m_point <= 0) m_point = 0.01;

   m_trade.SetExpertMagicNumber(InpMagic);
   m_trade.SetDeviationInPoints(50);
   m_trade.SetTypeFillingBySymbol(m_symbol);

   FileDelete(InpCommandFile, FILE_COMMON);

   EventSetMillisecondTimer(InpTimerMS);
   Print("🟢 [BonusHedge_Master] Initialized on ", m_symbol, " (Magic: ", InpMagic, ")");
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();
   Comment("");
}

//+------------------------------------------------------------------+
//| Timer event function                                             |
//+------------------------------------------------------------------+
void OnTimer()
{
   // 0. CHECK IF ALGO TRADING IS ALLOWED BY USER IN MT5
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED))
   {
      Comment("\n  ⚠️ [BonusHedge_Master] ALGO TRADING IS DISABLED IN MT5!\n" +
              "  Klik tombol 'Algo Trading' di toolbar atas MT5 agar robot bisa bekerja.");
      return;
   }

   // 1. Read Slave Telemetry (Two-Way Communication)
   ReadSlaveState();

   // 2. Check for incoming commands (e.g. CLOSE_ALL from Slave)
   CheckIncomingCommands();

   // 3. Check if Slave was liquidated / hit MC -> Harvest Master Profit
   if(InpHarvestOnSlaveMC && CheckSlaveLiquidationHarvest())
      return;

   // 4. Broadcast Master State to Slave via FILE_COMMON
   BroadcastMasterState();

   // 5. Manage Grid Logic (with pre-trade margin verification)
   if(!m_closing_active)
      ManageGrid();

   // 6. Update On-Screen Dashboard
   UpdateDashboard();
}

//+------------------------------------------------------------------+
//| Read Slave state from FILE_COMMON (Two-Way Telemetry)            |
//+------------------------------------------------------------------+
void ReadSlaveState()
{
   if(!FileIsExist(InpSlaveFile, FILE_COMMON))
   {
      m_slave_online = false;
      return;
   }

   int file_handle = FileOpen(InpSlaveFile, FILE_READ|FILE_BIN|FILE_COMMON|FILE_SHARE_WRITE);
   if(file_handle == INVALID_HANDLE) return;

   m_slave_time         = FileReadLong(file_handle);
   m_slave_login        = FileReadLong(file_handle);
   m_slave_equity       = FileReadDouble(file_handle);
   m_slave_balance      = FileReadDouble(file_handle);
   m_slave_free_margin  = FileReadDouble(file_handle);
   m_slave_margin_level = FileReadDouble(file_handle);
   m_slave_profit       = FileReadDouble(file_handle);
   m_slave_pos_count    = FileReadInteger(file_handle);

   if(m_slave_pos_count > 0 && m_slave_pos_count <= 100)
   {
      ArrayResize(m_slave_positions, m_slave_pos_count);
      for(int i = 0; i < m_slave_pos_count; i++)
      {
         m_slave_positions[i].ticket     = (ulong)FileReadLong(file_handle);
         m_slave_positions[i].type       = FileReadInteger(file_handle);
         m_slave_positions[i].volume     = FileReadDouble(file_handle);
         m_slave_positions[i].price_open = FileReadDouble(file_handle);
         m_slave_positions[i].profit     = FileReadDouble(file_handle);
         int clen = FileReadInteger(file_handle);
         if(clen > 0 && clen < 256)
            m_slave_positions[i].comment = FileReadString(file_handle, clen);
         else
            m_slave_positions[i].comment = "";
      }
   }
   else
   {
      ArrayResize(m_slave_positions, 0);
   }

   FileClose(file_handle);

   // Consider online if updated within last 5 seconds
   m_slave_online = (TimeLocal() - m_slave_time <= 5);
}

//+------------------------------------------------------------------+
//| Check if Slave got closed / stopped out / liquidated             |
//| IRONCLAD SAFETY: If Master has positions but Slave has 0        |
//| positions, Master MUST CLOSE ALL IMMEDIATELY!                   |
//+------------------------------------------------------------------+
bool CheckSlaveLiquidationHarvest()
{
   if(!m_slave_online || m_closing_active) return false;

   int master_positions = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0 && PositionGetString(POSITION_SYMBOL) == m_symbol && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
         master_positions++;
   }

   // JIKA MASTER ADA POSISI (sudah lewat grace period 5 detik), TAPI SLAVE SUDAH 0 POSISI:
   // Beri waktu 5 detik agar Slave sempat membuka posisi hedge.
   // Jika setelah 5 detik Slave tetap 0 posisi (atau posisi Slave ditutup), Master langsung tutup semua!
   if(master_positions > 0 && m_slave_pos_count == 0 && (TimeCurrent() - m_last_order_time >= 5))
   {
      Print("🚨 [CRITICAL HEDGE SAFETY] Slave account (", m_slave_login,
            ") posisi SUDAH TUTUP (0 posisi)! Menutup semua posisi Master sekarang!");
      m_closing_active = true;
      CloseAllMasterPositions();
      m_closing_active = false;
      m_last_order_time = TimeCurrent();
      return true;
   }

   return false;
}

//+------------------------------------------------------------------+
//| Main Grid Strategy Execution                                     |
//+------------------------------------------------------------------+
void ManageGrid()
{
   int    total_positions = 0;
   double total_profit    = 0.0;
   double min_price       = DBL_MAX;
   double max_price       = 0.0;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0
         && (StringCompare(PositionGetString(POSITION_SYMBOL), m_symbol, false) == 0 || StringCompare(PositionGetString(POSITION_SYMBOL), _Symbol, false) == 0)
         && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
      {
         total_positions++;
         total_profit += PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
         double open_p = PositionGetDouble(POSITION_PRICE_OPEN);
         if(open_p < min_price) min_price = open_p;
         if(open_p > max_price) max_price = open_p;
      }
   }

   // Auto-calculate Basket TP proportional to Initial Lot (Base: $31.74 per 0.10 lot)
   double effective_lot = InpInitialLot;
   double effective_basket_tp = (InpInitialLot / 0.10) * 31.74;
   if(InpBasketTPDollars > 0 && InpBasketTPDollars != 31.74)
   {
      effective_basket_tp = InpBasketTPDollars; // Use custom if user explicitly typed a custom amount
   }

   // --- CHECK COMBINED NET PROFIT (MASTER + SLAVE GABUNGAN PLUS) ---
   // Wajib gabungan Master + Slave agar 100% meng-cover semua spread dan komisi!
   double combined_net_profit = total_profit + (m_slave_online ? m_slave_profit : 0.0);

   if(total_positions > 0 && effective_basket_tp > 0 && combined_net_profit >= effective_basket_tp)
   {
      Print("🎉 [COMBINED NET TP TRIGGERED] Total Gabungan (Master+Slave): $", DoubleToString(combined_net_profit, 2),
            " >= Target $", DoubleToString(effective_basket_tp, 2), " (Semua Spread Ter-Cover!)");
      m_closing_active = true;
      CloseAllMasterPositions();
      SendCommandToSlave("CLOSE_ALL");
      m_closing_active = false;
      m_last_order_time = TimeCurrent();
      return;
   }


   // --- PRE-TRADE MARGIN CHECK (SELF & SLAVE) ---
   double my_free_margin  = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   double my_margin_level = AccountInfoDouble(ACCOUNT_MARGIN_LEVEL);

   // Do not open if Master's margin is critical
   if(my_free_margin < InpMinFreeMargin || (my_margin_level > 0 && my_margin_level < InpMinMarginLevel))
   {
      return; // Hold off, margin critical
   }

   // Do not open if Slave's margin is critical or Slave is offline
   if(total_positions > 0 && m_slave_online)
   {
      if(m_slave_free_margin < InpMinFreeMargin || (m_slave_margin_level > 0 && m_slave_margin_level < InpMinMarginLevel))
      {
         return; // Hold off, Slave cannot support another hedge layer
      }
   }

   // Cooldown between orders (10 seconds)
   if(TimeCurrent() - m_last_order_time < 10) return;

   MqlTick tick;
   if(!SymbolInfoTick(m_symbol, tick) || tick.bid <= 0) return;

   // --- LAYER 1 (INITIAL ORDER) ---
   if(total_positions == 0)
   {
      m_last_order_time = TimeCurrent(); // Update cooldown immediately to prevent rapid-fire loops
      string comment = InpCommentPrefix + "1";
      if(m_trade.Sell(effective_lot, m_symbol, tick.bid, 0, 0, comment))
      {
         Print("✅ [MASTER OPEN INITIAL] Layer 1: SELL ", effective_lot, "L @ ", tick.bid, " (", comment, ")");
      }
      return;
   }

   // --- NEXT LAYERS (GRID STEPS) ---
   if(total_positions < InpMaxLayers)
   {
      // SAFETY CHECK: Jangan pernah buka Layer berikutnya jika Slave belum berhasil meng-hedge layer sebelumnya!
      if(m_slave_online && m_slave_pos_count < total_positions)
      {
         return; // Hold off, tunggu Slave selesai hedge
      }

      double step_distance = InpGridStepPoints * m_point;
      bool should_open = false;

      if(min_price < DBL_MAX)
      {
         if((tick.bid - max_price) >= step_distance) should_open = true;
         if((min_price - tick.bid) >= step_distance) should_open = true;
      }

      if(should_open)
      {
         m_last_order_time = TimeCurrent(); // Update cooldown immediately
         string comment = InpCommentPrefix + IntegerToString(total_positions + 1);
         if(m_trade.Sell(effective_lot, m_symbol, tick.bid, 0, 0, comment))
         {
            Print("✅ [MASTER OPEN NEXT LAYER] Layer ", (total_positions + 1), ": SELL ",
                  effective_lot, "L @ ", tick.bid, " (", comment, ")");
         }
      }
   }
}

//+------------------------------------------------------------------+
//| Close all Master grid positions safely                           |
//+------------------------------------------------------------------+
void CloseAllMasterPositions()
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0
         && (StringCompare(PositionGetString(POSITION_SYMBOL), m_symbol, false) == 0 || StringCompare(PositionGetString(POSITION_SYMBOL), _Symbol, false) == 0)
         && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
      {
         m_trade.PositionClose(ticket);
      }
   }
}

//+------------------------------------------------------------------+
//| Broadcast Master State via FILE_COMMON (Includes Margin Data)    |
//+------------------------------------------------------------------+
void BroadcastMasterState()
{
   int count = 0;
   double total_prof = 0.0;
   ulong  tickets[];
   int    types[];
   double volumes[], prices[], profits[];
   string comments[];

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0
         && (StringCompare(PositionGetString(POSITION_SYMBOL), m_symbol, false) == 0 || StringCompare(PositionGetString(POSITION_SYMBOL), _Symbol, false) == 0)
         && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
      {
         ArrayResize(tickets,  count + 1);
         ArrayResize(types,    count + 1);
         ArrayResize(volumes,  count + 1);
         ArrayResize(prices,   count + 1);
         ArrayResize(profits,  count + 1);
         ArrayResize(comments, count + 1);

         tickets[count]  = ticket;
         types[count]    = (int)PositionGetInteger(POSITION_TYPE);
         volumes[count]  = PositionGetDouble(POSITION_VOLUME);
         prices[count]   = PositionGetDouble(POSITION_PRICE_OPEN);
         profits[count]  = PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
         comments[count] = PositionGetString(POSITION_COMMENT);
         total_prof     += profits[count];
         count++;
      }
   }

   int file_handle = FileOpen(InpMasterFile, FILE_WRITE|FILE_BIN|FILE_COMMON|FILE_SHARE_READ);
   if(file_handle == INVALID_HANDLE) return;

   FileWriteLong(file_handle, (long)TimeLocal());
   FileWriteLong(file_handle, AccountInfoInteger(ACCOUNT_LOGIN));
   FileWriteDouble(file_handle, AccountInfoDouble(ACCOUNT_EQUITY));
   FileWriteDouble(file_handle, AccountInfoDouble(ACCOUNT_BALANCE));
   FileWriteDouble(file_handle, AccountInfoDouble(ACCOUNT_MARGIN_FREE));
   FileWriteDouble(file_handle, AccountInfoDouble(ACCOUNT_MARGIN_LEVEL));
   FileWriteDouble(file_handle, total_prof);
   FileWriteInteger(file_handle, count);

   for(int i = 0; i < count; i++)
   {
      FileWriteLong(file_handle, (long)tickets[i]);
      FileWriteInteger(file_handle, types[i]);
      FileWriteDouble(file_handle, volumes[i]);
      FileWriteDouble(file_handle, prices[i]);
      FileWriteDouble(file_handle, profits[i]);
      int clen = StringLen(comments[i]);
      FileWriteInteger(file_handle, clen);
      if(clen > 0) FileWriteString(file_handle, comments[i], clen);
   }

   FileClose(file_handle);
}

//+------------------------------------------------------------------+
//| Check incoming commands from Slave                               |
//+------------------------------------------------------------------+
void CheckIncomingCommands()
{
   if(!FileIsExist(InpCommandFile, FILE_COMMON)) return;

   int file_handle = FileOpen(InpCommandFile, FILE_READ|FILE_BIN|FILE_COMMON);
   if(file_handle == INVALID_HANDLE) return;

   int clen = FileReadInteger(file_handle);
   string cmd = "";
   if(clen > 0) cmd = FileReadString(file_handle, clen);
   FileClose(file_handle);

   FileDelete(InpCommandFile, FILE_COMMON);

   if(cmd == "CLOSE_ALL" && !m_closing_active)
   {
      Print("🚨 [MASTER] Received CLOSE_ALL from Slave! Closing all positions.");
      m_closing_active = true;
      CloseAllMasterPositions();
      m_closing_active = false;
      m_last_order_time = TimeCurrent();
   }
}

void SendCommandToSlave(string cmd)
{
   int file_handle = FileOpen(InpCommandFile, FILE_WRITE|FILE_BIN|FILE_COMMON);
   if(file_handle != INVALID_HANDLE)
   {
      int clen = StringLen(cmd);
      FileWriteInteger(file_handle, clen);
      if(clen > 0) FileWriteString(file_handle, cmd, clen);
      FileClose(file_handle);
   }
}

//+------------------------------------------------------------------+
//| Draw On-Screen Dashboard                                         |
//+------------------------------------------------------------------+
void UpdateDashboard()
{
   int    total_positions = 0;
   double total_profit    = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0
         && PositionGetString(POSITION_SYMBOL) == m_symbol
         && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
      {
         total_positions++;
         total_profit += PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
      }
   }

   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double basket_tp = InpAutoScaleLot ? (balance / 1000.0) * InpBasketTPDollars : InpBasketTPDollars;

   string slave_info = m_slave_online ?
      ("Login: " + IntegerToString(m_slave_login) + " | Free: $" + DoubleToString(m_slave_free_margin, 2) + " (" + DoubleToString(m_slave_margin_level, 1) + "%)") :
      "OFFLINE / Not Connected";

   string text = "\n" +
      "  ╔════════════════════════════════════════════════════════════════╗\n" +
      "  ║   ⚡ DUAL-MT5 BONUS HEDGING - MASTER ENGINE (100870)          ║\n" +
      "  ╠════════════════════════════════════════════════════════════════╣\n" +
      "    Symbol          : " + m_symbol + "\n" +
      "    Account Login   : " + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "\n" +
      "    Balance / Equity: $" + DoubleToString(balance, 2) + " / $" + DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY), 2) + "\n" +
      "    Free Margin     : $" + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_FREE), 2) + " (" + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_LEVEL), 1) + "%)\n" +
      "    Active Layers   : " + IntegerToString(total_positions) + " / " + IntegerToString(InpMaxLayers) + "\n" +
      "    Master Floating : $" + DoubleToString(total_profit, 2) + "\n" +
      "    Target Basket TP: $" + DoubleToString(basket_tp, 2) + "\n" +
      "  ────────────────────────────────────────────────────────────────\n" +
      "    🔗 SLAVE TELEMETRY: " + slave_info + "\n" +
      "    Status          : " + (total_positions > 0 ? "✅ GRID ACTIVE (SYNC 50ms)" : "⏳ IDLE - Waiting") + "\n" +
      "  ╚════════════════════════════════════════════════════════════════╝\n";

   Comment(text);

   // Periodic Telegram Snapshot
   if(InpEnableTelegram && StringLen(InpTelegramBotToken) > 0 && StringLen(InpTelegramChatID) > 0)
   {
      if(TimeCurrent() - m_last_telegram_time >= InpTelegramIntervalMin * 60)
      {
         // Build Master position details
         string master_pos_details = "";
         for(int i = PositionsTotal() - 1; i >= 0; i--)
         {
            ulong t = PositionGetTicket(i);
            if(t > 0 && (StringCompare(PositionGetString(POSITION_SYMBOL), m_symbol, false) == 0 || StringCompare(PositionGetString(POSITION_SYMBOL), _Symbol, false) == 0) && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
            {
               double p_prof = PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
               string p_sign = (p_prof >= 0) ? "+$" : "-$";
               string p_type = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_SELL) ? "SELL" : "BUY";
               master_pos_details += "   └ #" + IntegerToString(t) + " " + p_type + " " + DoubleToString(PositionGetDouble(POSITION_VOLUME), 2) + "L @ " + DoubleToString(PositionGetDouble(POSITION_PRICE_OPEN), 2) + " (" + p_sign + DoubleToString(MathAbs(p_prof), 2) + ")%0A";
            }
         }
         if(master_pos_details == "") master_pos_details = "   └ (Tidak ada posisi aktif)%0A";

         // Build Slave position details
         string slave_pos_details = "";
         for(int i = 0; i < m_slave_pos_count; i++)
         {
            string s_type = (m_slave_positions[i].type == 1) ? "SELL" : "BUY";
            string s_sign = (m_slave_positions[i].profit >= 0) ? "+$" : "-$";
            slave_pos_details += "   └ #" + IntegerToString(m_slave_positions[i].ticket) + " " + s_type + " " + DoubleToString(m_slave_positions[i].volume, 2) + "L @ " + DoubleToString(m_slave_positions[i].price_open, 2) + " (" + s_sign + DoubleToString(MathAbs(m_slave_positions[i].profit), 2) + ")%0A";
         }
         if(slave_pos_details == "") slave_pos_details = "   └ (Tidak ada posisi aktif)%0A";

         string msg = "📊 <b>[LIVE DUAL-MT5 BONUS HEDGING]</b>%0A" +
            "────────────────────────────%0A" +
            "👑 <b>MASTER (" + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + ")</b>:%0A" +
            "   • Equity / Bal : $" + DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY), 2) + " / $" + DoubleToString(balance, 2) + "%0A" +
            "   • Margin Level : " + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_LEVEL), 1) + "%% (Free: $" + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_FREE), 2) + ")%0A" +
            "   • Floating : $" + DoubleToString(total_profit, 2) + " (" + IntegerToString(total_positions) + " Layers)%0A" +
            master_pos_details + "%0A" +
            "🛡️ <b>SLAVE (" + IntegerToString(m_slave_login) + " - Bonus 20%%)</b>:%0A" +
            "   • Equity / Bal : $" + DoubleToString(m_slave_equity, 2) + " / $" + DoubleToString(m_slave_balance, 2) + "%0A" +
            "   • Margin Level : " + DoubleToString(m_slave_margin_level, 1) + "%% (Free: $" + DoubleToString(m_slave_free_margin, 2) + ")%0A" +
            "   • Floating : $" + DoubleToString(m_slave_profit, 2) + " (" + IntegerToString(m_slave_pos_count) + " Hedges)%0A" +
            slave_pos_details +
            "────────────────────────────%0A" +
            "🎯 <b>NET COMBINED : " + sign + DoubleToString(MathAbs(net_fl), 2) + "</b>%0A" +
            "🎯 <b>TARGET PLUS : +$" + DoubleToString(basket_tp, 2) + "</b>";

         SendTelegramMessage(msg);
      }
   }
}

//+------------------------------------------------------------------+
//| Helper: Send Message to Telegram API                             |
//+------------------------------------------------------------------+
void SendTelegramMessage(string msg_url_encoded)
{
   if(!InpEnableTelegram || StringLen(InpTelegramBotToken) == 0 || StringLen(InpTelegramChatID) == 0) return;

   string url = "https://api.telegram.org/bot" + InpTelegramBotToken + "/sendMessage?chat_id=" + InpTelegramChatID + "&text=" + msg_url_encoded + "&parse_mode=HTML";
   char post_data[], result[];
   string result_headers;

   ResetLastError();
   WebRequest("GET", url, NULL, 3000, post_data, result, result_headers);
}

