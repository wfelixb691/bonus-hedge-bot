"""
Telegram Live Reporter for Dual-MT5 Bonus Hedging Bot.
Reads binary telemetry from MT5 FILE_COMMON and sends real-time updates directly to your Telegram.
"""

import os
import sys
import json
import time
import urllib.request
import urllib.parse
from live_dashboard import read_master_data, read_slave_data, build_dashboard_data, COMMON_DIR

CONFIG_FILE = "telegram_config.json"


def load_config() -> dict:
    if not os.path.isfile(CONFIG_FILE):
        default_cfg = {
            "telegram_bot_token": "PASTE_BOT_TOKEN_DISINI",
            "telegram_chat_id": "PASTE_CHAT_ID_DISINI",
            "report_interval_seconds": 60,
            "send_on_position_change": True
        }
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(default_cfg, f, indent=2)
        return default_cfg

    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


import ssl

# Create unverified SSL context to bypass Windows VPS certificate validation issues
SSL_CTX = ssl._create_unverified_context()


def send_telegram(token: str, chat_id: str, message: str):
    if not token or not chat_id or "PASTE_" in token:
        return

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": message,
        "parse_mode": "HTML"
    }
    try:
        data = urllib.parse.urlencode(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data)
        with urllib.request.urlopen(req, data=data, context=SSL_CTX, timeout=10) as resp:
            pass
    except Exception as e:
        print(f"⚠️ [Telegram Error] {e}")



def format_report_message(data: dict) -> str:
    m = data.get("master", {})
    s = data.get("slave", {})
    net_fl = data.get("net_floating", 0.0)
    pairs = data.get("pairs", [])
    target = data.get("target_tp", 31.74)

    sign = "+$" if net_fl >= 0 else "-$"
    icon = "🟢" if net_fl >= 0 else "🔴"

    m_eq = f"${m.get('equity', 0):,.2f}"
    m_bal = f"${m.get('balance', 0):,.2f}"
    m_ml = f"{m.get('margin_level', 0):.1f}%"
    m_prof = f"{'+$' if m.get('profit', 0) >= 0 else '-$'}{abs(m.get('profit', 0)):.2f}"

    s_eq = f"${s.get('equity', 0):,.2f}"
    s_bal = f"${s.get('balance', 0):,.2f}"
    s_ml = f"{s.get('margin_level', 0):.1f}%"
    s_prof = f"{'+$' if s.get('profit', 0) >= 0 else '-$'}{abs(s.get('profit', 0)):.2f}"

    pairs_text = ""
    if pairs:
        for i, p in enumerate(pairs, 1):
            p_sign = "+$" if p['net_profit'] >= 0 else "-$"
            pairs_text += f"\n   • Pair #{i}: S {p['master_vol']}L ⇄ B {p['slave_vol']}L (Net: {p_sign}{abs(p['net_profit']):.2f})"
    else:
        pairs_text = "\n   • Menunggu order aktif..."

    msg = f"""📊 <b>DUAL-MT5 BONUS HEDGING REPORT</b>
────────────────────────────
👑 <b>MASTER ({m.get('login', 100870)})</b>:
   • Equity / Bal : {m_eq} / {m_bal}
   • Margin Level : {m_ml}
   • Floating     : {m_prof} ({m.get('count', 0)} Layers)

🛡️ <b>SLAVE ({s.get('login', 100871)} - Bonus 20%)</b>:
   • Equity / Bal : {s_eq} / {s_bal}
   • Margin Level : {s_ml}
   • Floating     : {s_prof} ({s.get('count', 0)} Hedges)
────────────────────────────
🎯 <b>NET FLOATING : {icon} {sign}{abs(net_fl):.2f}</b>
🎯 <b>TARGET PLUS : +${target:.2f}</b>
📈 <b>ACTIVE PAIRS ({len(pairs)}):</b>{pairs_text}"""
    return msg


def main():
    cfg = load_config()
    token = cfg.get("telegram_bot_token", "")
    chat_id = cfg.get("telegram_chat_id", "")
    interval = cfg.get("report_interval_seconds", 60)

    print("=" * 60)
    print(" 🚀 TELEGRAM LIVE REPORTER AKTIF!")
    print(f" 👉 Shared Folder MT5 : {COMMON_DIR}")
    print(f" 👉 Interval Laporan  : Setiap {interval} detik")
    print("=" * 60)

    if not token or "PASTE_" in token or not chat_id:
        print("\n⚠️ PERHATIAN: Masukkan Token Bot & Chat ID di file 'telegram_config.json'")
        print("   1. Buka telegram_config.json")
        print("   2. Isi 'telegram_bot_token' dan 'telegram_chat_id'")
        print("   3. Jalankan kembali script ini.\n")

    last_count = -1
    last_send = 0

    while True:
        try:
            d = build_dashboard_data()
            curr_count = len(d.get("pairs", []))

            # Send if interval elapsed OR if position count changed
            send_now = False
            if time.time() - last_send >= interval:
                send_now = True
            elif cfg.get("send_on_position_change", True) and last_count != -1 and curr_count != last_count:
                send_now = True

            if send_now and token and "PASTE_" not in token and chat_id:
                msg = format_report_message(d)
                send_telegram(token, chat_id, msg)
                print(f"[{time.strftime('%H:%M:%S')}] ✅ Laporan terkirim ke Telegram | Net Floating: ${d.get('net_floating', 0.0):.2f}")
                last_send = time.time()
                last_count = curr_count

        except Exception as e:
            print(f"Error loop: {e}")

        time.sleep(2)


if __name__ == "__main__":
    main()
