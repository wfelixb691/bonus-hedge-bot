//+------------------------------------------------------------------+
//|                                            BonusHedge_Slave.mq5  |
//|                          All-in-One Dual-MT5 Bonus Hedger Slave  |
//|                                  Copyright 2026, Advanced Bot EA |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Advanced Bot EA"
#property link      "https://www.mql5.com"
#property version   "1.20"
#property strict

#include <Trade\Trade.mqh>

//--- Input Parameters
input group "=== SLAVE HEDGING PARAMETERS ==="
input string   InpSymbol            = "XAUUSD";      // Trading Symbol
input double   InpLotMultiplier     = 1.10;          // Lot Multiplier (e.g. 0.30 -> 0.33)
input double   InpCombinedNetTP     = 31.74;         // Combined Net TP (Master + Slave floating $)
input ulong    InpMagic             = 888999;        // Slave Hedger Magic Number
input string   InpCommentPrefix     = "CT#";         // Comment Tag Prefix for Hedged Positions
input int      InpSlippage          = 50;            // Slippage Points

input group "=== MARGIN & CIRCUIT BREAKER (CROSS-CHECK) ==="
input double   InpMinFreeMargin     = 10.0;          // Min Free Margin $ threshold
input bool     InpHarvestOnMasterMC = true;          // Auto Close Slave if Master hits Margin Call/StopOut

input group "=== BRIDGE & COMM SETTINGS ==="
input string   InpMasterFile        = "bonus_hedge_master.dat";   // Master State File (FILE_COMMON)
input string   InpSlaveFile         = "bonus_hedge_slave.dat";    // Slave State File (FILE_COMMON)
input string   InpCommandFile       = "bonus_hedge_command.dat";  // Command File (FILE_COMMON)
input int      InpTimerMS           = 50;                         // Sync Interval in ms

//--- Structure for Master Position
struct SMasterPos
{
   ulong    ticket;
   int      type;       // 0=BUY, 1=SELL
   double   volume;
   double   price_open;
   double   profit;
   string   comment;
};

//--- Global State
CTrade         m_trade;
string         m_symbol             = "";
double         m_point              = 0.01;
int            m_digits             = 2;
bool           m_closing_active     = false;

// Master state snapshot
long           m_master_time        = 0;
long           m_master_login       = 0;
double         m_master_equity      = 0.0;
double         m_master_balance     = 0.0;
double         m_master_free_margin = 0.0;
double         m_master_margin_level= 0.0;
double         m_master_profit      = 0.0;
int            m_master_pos_count   = 0;
SMasterPos     m_master_positions[];
bool           m_master_online      = false;

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
   m_symbol = (InpSymbol == "" || InpSymbol == "0") ? _Symbol : InpSymbol;
   if(!SymbolSelect(m_symbol, true)) m_symbol = _Symbol;

   m_point  = SymbolInfoDouble(m_symbol, SYMBOL_POINT);
   m_digits = (int)SymbolInfoInteger(m_symbol, SYMBOL_DIGITS);
   if(m_point <= 0) m_point = 0.01;

   m_trade.SetExpertMagicNumber(InpMagic);
   m_trade.SetDeviationInPoints(InpSlippage);
   m_trade.SetTypeFillingBySymbol(m_symbol);

   EventSetMillisecondTimer(InpTimerMS);
   Print("🟢 [BonusHedge_Slave] Initialized on ", m_symbol,
         " (Magic: ", InpMagic, ", Mult: ", DoubleToString(InpLotMultiplier, 2), "x)");
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();
   Comment("");
}

//+------------------------------------------------------------------+
//| Timer event function                                             |
//+------------------------------------------------------------------+
void OnTimer()
{
   // 0. CHECK IF ALGO TRADING IS ALLOWED BY USER IN MT5
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED))
   {
      Comment("\n  ⚠️ [BonusHedge_Slave] ALGO TRADING IS DISABLED IN MT5!\n" +
              "  Klik tombol 'Algo Trading' di toolbar atas MT5 agar robot bisa bekerja.");
      return;
   }

   // 1. Broadcast Slave Telemetry to Master (Two-Way Communication)
   BroadcastSlaveState();

   // 2. Read Master State from FILE_COMMON
   if(!ReadMasterState())
   {
      UpdateDashboardOffline();
      return;
   }

   // 3. Calculate Slave Floating & Combined Net Profit
   double slave_profit        = GetSlaveTotalProfit();
   double combined_net_profit = m_master_profit + slave_profit;

   // 4. Check if Master was liquidated / hit MC -> Harvest Slave Profit immediately!
   if(InpHarvestOnMasterMC && CheckMasterLiquidationHarvest())
      return;

   // Auto-calculate Combined TP target proportional to Master Lot ($31.74 per 0.10 lot)
   double effective_net_tp = InpCombinedNetTP;
   if(m_master_pos_count > 0 && m_master_positions[0].volume > 0)
   {
      effective_net_tp = (m_master_positions[0].volume / 0.10) * 31.74;
   }
   if(InpCombinedNetTP > 0 && InpCombinedNetTP != 31.74)
   {
      effective_net_tp = InpCombinedNetTP; // Use custom if user explicitly typed a custom amount
   }

   // 5. CHECK COMBINED NET PROFIT TARGET (GABUNGAN PLUS!)
   if(!m_closing_active
      && m_master_pos_count > 0
      && effective_net_tp > 0
      && combined_net_profit >= effective_net_tp)
   {
      Print("🎉 [COMBINED NET TP] Combined Profit: $", DoubleToString(combined_net_profit, 2),
            " >= Target $", DoubleToString(effective_net_tp, 2));
      m_closing_active = true;
      CloseAllSlavePositions();
      SendCommandToMaster("CLOSE_ALL");
      m_closing_active = false;
      slave_profit        = GetSlaveTotalProfit();
      combined_net_profit = m_master_profit + slave_profit;
      UpdateDashboard(slave_profit, combined_net_profit);
      return;
   }

   // 6. Sync Open: Hedge any new Master position on Slave
   if(!m_closing_active)
      SyncOpenPositions();

   // 7. Sync Close: Close Slave position if Master position was closed
   if(!m_closing_active)
      SyncClosePositions();

   // 8. Update Dashboard
   UpdateDashboard(slave_profit, combined_net_profit);
}

//+------------------------------------------------------------------+
//| Broadcast Slave state to Master via FILE_COMMON                  |
//+------------------------------------------------------------------+
void BroadcastSlaveState()
{
   int count = 0;
   double total_prof = 0.0;
   ulong  tickets[];
   int    types[];
   double volumes[], prices[], profits[];
   string comments[];

   for(int s = PositionsTotal() - 1; s >= 0; s--)
   {
      ulong ticket = PositionGetTicket(s);
      if(ticket > 0 && (StringCompare(PositionGetString(POSITION_SYMBOL), m_symbol, false) == 0 || StringCompare(PositionGetString(POSITION_SYMBOL), _Symbol, false) == 0) && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
      {
         ArrayResize(tickets,  count + 1);
         ArrayResize(types,    count + 1);
         ArrayResize(volumes,  count + 1);
         ArrayResize(prices,   count + 1);
         ArrayResize(profits,  count + 1);
         ArrayResize(comments, count + 1);

         tickets[count]  = ticket;
         types[count]    = (int)PositionGetInteger(POSITION_TYPE);
         volumes[count]  = PositionGetDouble(POSITION_VOLUME);
         prices[count]   = PositionGetDouble(POSITION_PRICE_OPEN);
         profits[count]  = PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
         comments[count] = PositionGetString(POSITION_COMMENT);
         total_prof     += profits[count];
         count++;
      }
   }

   int file_handle = FileOpen(InpSlaveFile, FILE_WRITE|FILE_BIN|FILE_COMMON|FILE_SHARE_READ);
   if(file_handle == INVALID_HANDLE) return;

   FileWriteLong(file_handle, (long)TimeLocal());
   FileWriteLong(file_handle, AccountInfoInteger(ACCOUNT_LOGIN));
   FileWriteDouble(file_handle, AccountInfoDouble(ACCOUNT_EQUITY));
   FileWriteDouble(file_handle, AccountInfoDouble(ACCOUNT_BALANCE));
   FileWriteDouble(file_handle, AccountInfoDouble(ACCOUNT_MARGIN_FREE));
   FileWriteDouble(file_handle, AccountInfoDouble(ACCOUNT_MARGIN_LEVEL));
   FileWriteDouble(file_handle, total_prof);
   FileWriteInteger(file_handle, count);

   for(int i = 0; i < count; i++)
   {
      FileWriteLong(file_handle, (long)tickets[i]);
      FileWriteInteger(file_handle, types[i]);
      FileWriteDouble(file_handle, volumes[i]);
      FileWriteDouble(file_handle, prices[i]);
      FileWriteDouble(file_handle, profits[i]);
      int clen = StringLen(comments[i]);
      FileWriteInteger(file_handle, clen);
      if(clen > 0) FileWriteString(file_handle, comments[i], clen);
   }

   FileClose(file_handle);
}

//+------------------------------------------------------------------+
//| Read Master state from FILE_COMMON                               |
//+------------------------------------------------------------------+
bool ReadMasterState()
{
   if(!FileIsExist(InpMasterFile, FILE_COMMON))
   {
      m_master_online = false;
      return false;
   }

   int file_handle = FileOpen(InpMasterFile, FILE_READ|FILE_BIN|FILE_COMMON|FILE_SHARE_WRITE);
   if(file_handle == INVALID_HANDLE) return false;

   m_master_time         = FileReadLong(file_handle);
   m_master_login        = FileReadLong(file_handle);
   m_master_equity       = FileReadDouble(file_handle);
   m_master_balance      = FileReadDouble(file_handle);
   m_master_free_margin  = FileReadDouble(file_handle);
   m_master_margin_level = FileReadDouble(file_handle);
   m_master_profit       = FileReadDouble(file_handle);
   m_master_pos_count    = FileReadInteger(file_handle);

   if(m_master_pos_count < 0 || m_master_pos_count > 100)
   {
      FileClose(file_handle);
      return false;
   }

   ArrayResize(m_master_positions, m_master_pos_count);
   for(int i = 0; i < m_master_pos_count; i++)
   {
      m_master_positions[i].ticket     = (ulong)FileReadLong(file_handle);
      m_master_positions[i].type       = FileReadInteger(file_handle);
      m_master_positions[i].volume     = FileReadDouble(file_handle);
      m_master_positions[i].price_open = FileReadDouble(file_handle);
      m_master_positions[i].profit     = FileReadDouble(file_handle);
      int clen = FileReadInteger(file_handle);
      if(clen > 0 && clen < 256)
         m_master_positions[i].comment = FileReadString(file_handle, clen);
      else
         m_master_positions[i].comment = "";
   }

   FileClose(file_handle);
   m_master_online = (TimeLocal() - m_master_time <= 5);
   return true;
}

//+------------------------------------------------------------------+
//| Check if Master got closed / stopped out / liquidated            |
//| IRONCLAD SAFETY: If Slave has positions but Master has 0        |
//| positions, Slave MUST CLOSE ALL IMMEDIATELY!                    |
//+------------------------------------------------------------------+
bool CheckMasterLiquidationHarvest()
{
   if(!m_master_online || m_closing_active) return false;

   int slave_positions = 0;
   for(int s = PositionsTotal() - 1; s >= 0; s--)
   {
      ulong s_ticket = PositionGetTicket(s);
      if(s_ticket > 0 && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
         slave_positions++;
   }

   // JIKA SLAVE MASIH ADA POSISI, TAPI MASTER SUDAH 0 POSISI:
   // Slave WAJIB LANGSUNG TUTUP SEMUA detik itu juga!
   if(slave_positions > 0 && m_master_pos_count == 0)
   {
      Print("🚨 [CRITICAL HEDGE SAFETY] Master account (", m_master_login,
            ") posisi SUDAH TUTUP (0 posisi)! Menutup semua posisi Slave sekarang!");
      m_closing_active = true;
      CloseAllSlavePositions();
      m_closing_active = false;
      return true;
   }

   return false;
}

//+------------------------------------------------------------------+
//| Sync Open: Open matching reverse positions on Slave              |
//+------------------------------------------------------------------+
void SyncOpenPositions()
{
   MqlTick tick;
   if(!SymbolInfoTick(m_symbol, tick) || tick.ask <= 0) return;

   // Check if Slave has enough free margin before opening new hedge
   double my_free_margin = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   if(my_free_margin < InpMinFreeMargin)
   {
      Print("⚠️ [SLAVE MARGIN WARNING] Free margin low ($", DoubleToString(my_free_margin, 2), ") - Cannot open new hedge!");
      return;
   }

   for(int m_idx = 0; m_idx < m_master_pos_count; m_idx++)
   {
      ulong  m_ticket         = m_master_positions[m_idx].ticket;
      string expected_comment = InpCommentPrefix + IntegerToString(m_ticket);

      bool already_hedged = false;
      for(int s = PositionsTotal() - 1; s >= 0; s--)
      {
         ulong s_ticket = PositionGetTicket(s);
         if(s_ticket > 0 && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic
            && PositionGetString(POSITION_COMMENT) == expected_comment)
         {
            already_hedged = true;
            break;
         }
      }

      if(!already_hedged)
      {
         double raw_lot   = m_master_positions[m_idx].volume * InpLotMultiplier;
         double slave_lot = MathRound(raw_lot * 100.0) / 100.0;
         slave_lot        = MathMax(0.01, MathMin(50.0, slave_lot));

         bool order_ok = false;
         if(m_master_positions[m_idx].type == 1) // Master SELL -> Slave BUY
         {
            order_ok = m_trade.Buy(slave_lot, m_symbol, tick.ask, 0, 0, expected_comment);
         }
         else if(m_master_positions[m_idx].type == 0) // Master BUY -> Slave SELL
         {
            order_ok = m_trade.Sell(slave_lot, m_symbol, tick.bid, 0, 0, expected_comment);
         }

         if(order_ok)
         {
            Print("✅ [HEDGE OPEN SUCCESS] Master #", m_ticket, " -> Slave ", slave_lot, "L (", expected_comment, ")");
         }
         else
         {
            // CRITICAL ROLLBACK: Jika Slave gagal buka hedge (misal not enough money),
            // Master WAJIB LANGSUNG DI-CLOSE agar tidak floating sendirian tanpa pasangan!
            Print("🚨 [HEDGE FAILED] Slave gagal buka order (Code=", m_trade.ResultRetcode(),
                  " ", m_trade.ResultComment(), ")! Mengirim sinyal CLOSE_ALL ke Master untuk keamanan!");
            SendCommandToMaster("CLOSE_ALL");
         }
      }
   }
}

//+------------------------------------------------------------------+
//| Sync Close: Close Slave positions when Master closed             |
//+------------------------------------------------------------------+
void SyncClosePositions()
{
   for(int s = PositionsTotal() - 1; s >= 0; s--)
   {
      ulong s_ticket = PositionGetTicket(s);
      if(s_ticket <= 0) continue;
      if(PositionGetInteger(POSITION_MAGIC) != (long)InpMagic) continue;

      string comment = PositionGetString(POSITION_COMMENT);
      if(StringFind(comment, InpCommentPrefix) != 0) continue;

      string ticket_str = StringSubstr(comment, StringLen(InpCommentPrefix));
      ulong  m_ticket   = (ulong)StringToInteger(ticket_str);
      if(m_ticket == 0) continue;

      bool master_still_open = false;
      for(int m_idx = 0; m_idx < m_master_pos_count; m_idx++)
      {
         if(m_master_positions[m_idx].ticket == m_ticket)
         {
            master_still_open = true;
            break;
         }
      }

      if(!master_still_open)
      {
         Print("⚡ [SYNC CLOSE] Master #", m_ticket, " closed -> Closing Slave #", s_ticket);
         m_trade.PositionClose(s_ticket);
      }
   }
}

//+------------------------------------------------------------------+
//| Helper: Get total profit of Slave positions                      |
//+------------------------------------------------------------------+
double GetSlaveTotalProfit()
{
   double total = 0.0;
   for(int s = PositionsTotal() - 1; s >= 0; s--)
   {
      ulong s_ticket = PositionGetTicket(s);
      if(s_ticket > 0 && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
         total += PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
   }
   return total;
}

//+------------------------------------------------------------------+
//| Helper: Close all Slave positions                                |
//+------------------------------------------------------------------+
void CloseAllSlavePositions()
{
   for(int s = PositionsTotal() - 1; s >= 0; s--)
   {
      ulong s_ticket = PositionGetTicket(s);
      if(s_ticket > 0 && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
      {
         m_trade.PositionClose(s_ticket);
      }
   }
}

void SendCommandToMaster(string cmd)
{
   int file_handle = FileOpen(InpCommandFile, FILE_WRITE|FILE_BIN|FILE_COMMON);
   if(file_handle != INVALID_HANDLE)
   {
      int clen = StringLen(cmd);
      FileWriteInteger(file_handle, clen);
      if(clen > 0) FileWriteString(file_handle, cmd, clen);
      FileClose(file_handle);
   }
}

//+------------------------------------------------------------------+
//| Draw On-Screen Dashboard                                         |
//+------------------------------------------------------------------+
void UpdateDashboard(double slave_profit, double combined_net_profit)
{
   int slave_pos_count = 0;
   for(int s = PositionsTotal() - 1; s >= 0; s--)
   {
      ulong s_ticket = PositionGetTicket(s);
      if(s_ticket > 0 && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
         slave_pos_count++;
   }

   string profit_sign = (combined_net_profit >= 0) ? "🟢 +" : "🔴 ";
   string status_str  = (slave_pos_count > 0) ? "✅ HEDGING ACTIVE (50ms sync)" : "⏳ IDLE - Waiting Master";

   string text = "\n" +
      "  ╔════════════════════════════════════════════════════════════════╗\n" +
      "  ║   ⚡ DUAL-MT5 BONUS HEDGING - SLAVE LP ENGINE (100871)        ║\n" +
      "  ╠════════════════════════════════════════════════════════════════╣\n" +
      "    [MASTER ACCOUNT " + IntegerToString(m_master_login) + "]\n" +
      "      Equity / Balance: $" + DoubleToString(m_master_equity, 2) + " / $" + DoubleToString(m_master_balance, 2) + "\n" +
      "      Free Margin     : $" + DoubleToString(m_master_free_margin, 2) + " (" + DoubleToString(m_master_margin_level, 1) + "%)\n" +
      "      Floating        : $" + DoubleToString(m_master_profit, 2) + "\n" +
      "      Layers          : " + IntegerToString(m_master_pos_count) + " Active\n" +
      "  ────────────────────────────────────────────────────────────────\n" +
      "    [SLAVE ACCOUNT 100871 (BONUS 20% LP)]\n" +
      "      Equity / Balance: $" + DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY), 2) + " / $" + DoubleToString(AccountInfoDouble(ACCOUNT_BALANCE), 2) + "\n" +
      "      Credit (Bonus)  : $" + DoubleToString(AccountInfoDouble(ACCOUNT_CREDIT), 2) + "\n" +
      "      Free Margin     : $" + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_FREE), 2) + " (" + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_LEVEL), 1) + "%)\n" +
      "      Floating        : $" + DoubleToString(slave_profit, 2) + "\n" +
      "      Hedges          : " + IntegerToString(slave_pos_count) + " Pairs (x" + DoubleToString(InpLotMultiplier, 2) + " Lot)\n" +
      "  ────────────────────────────────────────────────────────────────\n" +
      "    🎯 NET COMBINED PROFIT : " + profit_sign + DoubleToString(combined_net_profit, 2) + "\n" +
      "    🎯 TARGET GABUNGAN (+) : +$" + DoubleToString(InpCombinedNetTP, 2) + "\n" +
      "    Status : " + status_str + "\n" +
      "  ╚════════════════════════════════════════════════════════════════╝\n";

   Comment(text);
}

void UpdateDashboardOffline()
{
   Comment("\n  ⚠️ [BonusHedge_Slave] Menunggu data dari Master EA...\n" +
           "  Pastikan BonusHedge_Master.mq5 sudah aktif di chart MT5 Master (100870).");
}
