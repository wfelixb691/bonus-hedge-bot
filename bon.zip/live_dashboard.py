"""
Live Visual Web Dashboard for Dual-MT5 Bonus Hedging Bot.
Reads binary telemetry from MT5 FILE_COMMON and serves a real-time web UI matching your exact dashboard layout.
"""

import os
import sys
import struct
import json
import time
import socket
import subprocess
import threading
import re
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

PORT = 8888


def find_common_files_dir() -> str:
    """Finds the MT5 Terminal Common Files directory on Windows."""
    appdata = os.environ.get("APPDATA", "")
    if appdata:
        common_path = os.path.join(appdata, "MetaQuotes", "Terminal", "Common", "Files")
        if os.path.isdir(common_path):
            return common_path

    userprofile = os.environ.get("USERPROFILE", "")
    if userprofile:
        cand = os.path.join(userprofile, "AppData", "Roaming", "MetaQuotes", "Terminal", "Common", "Files")
        if os.path.isdir(cand):
            return cand

    return "."


COMMON_DIR = find_common_files_dir()


def read_master_data() -> dict:
    filepath = os.path.join(COMMON_DIR, "bonus_hedge_master.dat")
    if not os.path.isfile(filepath):
        return {"online": False, "count": 0, "positions": []}

    try:
        with open(filepath, "rb") as f:
            data = f.read()

        if len(data) < 52:
            return {"online": False, "count": 0, "positions": []}

        offset = 0
        t_stamp, login, equity, balance, free_margin, margin_level, total_prof, count = struct.unpack_from("<qqdddddi", data, offset)
        offset += struct.calcsize("<qqdddddi")

        positions = []
        for _ in range(count):
            if offset + 36 > len(data):
                break
            ticket, p_type, vol, price_open, profit, clen = struct.unpack_from("<qidddi", data, offset)
            offset += struct.calcsize("<qidddi")
            comment = ""
            if clen > 0 and offset + clen <= len(data):
                comment = data[offset:offset+clen].decode("utf-8", errors="ignore")
                offset += clen

            positions.append({
                "ticket": ticket,
                "type": "BUY" if p_type == 0 else "SELL",
                "volume": round(vol, 2),
                "price_open": round(price_open, 2),
                "profit": round(profit, 2),
                "comment": comment
            })

        is_online = (time.time() - t_stamp <= 5) if t_stamp > 0 else False
        return {
            "online": is_online,
            "timestamp": t_stamp,
            "login": login,
            "equity": round(equity, 2),
            "balance": round(balance, 2),
            "free_margin": round(free_margin, 2),
            "margin_level": round(margin_level, 2),
            "profit": round(total_prof, 2),
            "count": count,
            "positions": positions
        }
    except Exception as e:
        return {"online": False, "count": 0, "positions": [], "error": str(e)}


def read_slave_data() -> dict:
    filepath = os.path.join(COMMON_DIR, "bonus_hedge_slave.dat")
    if not os.path.isfile(filepath):
        return {"online": False, "count": 0, "positions": []}

    try:
        with open(filepath, "rb") as f:
            data = f.read()

        if len(data) < 52:
            return {"online": False, "count": 0, "positions": []}

        offset = 0
        t_stamp, login, equity, balance, free_margin, margin_level, total_prof, count = struct.unpack_from("<qqdddddi", data, offset)
        offset += struct.calcsize("<qqdddddi")

        positions = []
        for _ in range(count):
            if offset + 36 > len(data):
                break
            ticket, p_type, vol, price_open, profit, clen = struct.unpack_from("<qidddi", data, offset)
            offset += struct.calcsize("<qidddi")
            comment = ""
            if clen > 0 and offset + clen <= len(data):
                comment = data[offset:offset+clen].decode("utf-8", errors="ignore")
                offset += clen

            positions.append({
                "ticket": ticket,
                "type": "BUY" if p_type == 0 else "SELL",
                "volume": round(vol, 2),
                "price_open": round(price_open, 2),
                "profit": round(profit, 2),
                "comment": comment
            })

        is_online = (time.time() - t_stamp <= 5) if t_stamp > 0 else False
        return {
            "online": is_online,
            "timestamp": t_stamp,
            "login": login,
            "equity": round(equity, 2),
            "balance": round(balance, 2),
            "free_margin": round(free_margin, 2),
            "margin_level": round(margin_level, 2),
            "profit": round(total_prof, 2),
            "count": count,
            "positions": positions
        }
    except Exception as e:
        return {"online": False, "count": 0, "positions": [], "error": str(e)}


def build_dashboard_data() -> dict:
    m = read_master_data()
    s = read_slave_data()

    m_prof = m.get("profit", 0.0) if m.get("online") else 0.0
    s_prof = s.get("profit", 0.0) if s.get("online") else 0.0
    net_floating = round(m_prof + s_prof, 2)

    m_positions = m.get("positions", [])
    s_positions = s.get("positions", [])

    pairs = []
    for m_pos in m_positions:
        m_t = m_pos["ticket"]
        tag = f"CT#{m_t}"
        matching_s = next((p for p in s_positions if tag in p.get("comment", "")), None)

        pair_net = round(m_pos["profit"] + (matching_s["profit"] if matching_s else 0.0), 2)
        pairs.append({
            "master_ticket": m_t,
            "master_type": m_pos["type"],
            "master_vol": m_pos["volume"],
            "master_price": m_pos["price_open"],
            "master_profit": m_pos["profit"],
            "slave_ticket": matching_s["ticket"] if matching_s else "-",
            "slave_type": matching_s["type"] if matching_s else "-",
            "slave_vol": matching_s["volume"] if matching_s else 0.0,
            "slave_price": matching_s["price_open"] if matching_s else 0.0,
            "slave_profit": matching_s["profit"] if matching_s else 0.0,
            "net_profit": pair_net
        })

    try:
        host_ip = socket.gethostbyname(socket.gethostname())
    except Exception:
        host_ip = "127.0.0.1"

    return {
        "host_ip": host_ip,
        "net_floating": net_floating,
        "target_tp": 31.74,
        "master": m,
        "slave": s,
        "pairs": pairs,
        "common_dir": COMMON_DIR
    }


HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dual-MT5 Bonus Hedging Live Dashboard</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #0b0f19;
      --card-bg: #131b2e;
      --card-border: #1e293b;
      --text: #f8fafc;
      --text-muted: #94a3b8;
      --green: #10b981;
      --green-bg: rgba(16, 185, 129, 0.15);
      --red: #ef4444;
      --red-bg: rgba(239, 68, 68, 0.15);
      --gold: #f59e0b;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Inter', sans-serif; }
    body { background: var(--bg); color: var(--text); padding: 20px; display: flex; justify-content: center; min-height: 100vh; }
    .container { width: 100%; max-width: 650px; display: flex; flex-direction: column; gap: 16px; }
    
    .top-bar { display: flex; justify-content: space-between; align-items: center; padding: 14px 18px; background: var(--card-bg); border: 1px solid var(--card-border); border-radius: 14px; }
    .live-badge { display: flex; align-items: center; gap: 8px; font-weight: 700; font-size: 14px; }
    .live-dot { width: 10px; height: 10px; border-radius: 50%; background: var(--green); box-shadow: 0 0 10px var(--green); animation: pulse 1.5s infinite; }
    @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
    .net-floating { font-size: 28px; font-weight: 900; font-family: 'JetBrains Mono', monospace; }
    .net-positive { color: var(--green); }
    .net-negative { color: var(--red); }

    .target-box { background: var(--card-bg); border: 1px solid var(--card-border); border-radius: 14px; padding: 14px 18px; display: flex; justify-content: space-between; align-items: center; }
    .target-title { font-size: 12px; font-weight: 700; color: var(--text-muted); }
    .target-val { font-size: 16px; font-weight: 800; font-family: 'JetBrains Mono', monospace; color: var(--gold); }

    .accounts-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    .account-card { background: var(--card-bg); border: 1px solid var(--card-border); border-radius: 14px; padding: 16px; display: flex; flex-direction: column; gap: 12px; }
    .acc-header { text-align: center; font-size: 13px; font-weight: 800; letter-spacing: 1px; color: var(--text-muted); border-bottom: 1px solid var(--card-border); padding-bottom: 8px; }
    .stat-row { display: flex; flex-direction: column; gap: 2px; }
    .stat-label { font-size: 11px; font-weight: 600; color: var(--text-muted); text-transform: uppercase; }
    .stat-val { font-size: 18px; font-weight: 800; font-family: 'JetBrains Mono', monospace; color: var(--text); }
    .stat-sub { font-size: 11px; color: var(--text-muted); }

    .pairs-card { background: var(--card-bg); border: 1px solid var(--card-border); border-radius: 14px; padding: 16px; display: flex; flex-direction: column; gap: 12px; }
    .pairs-header { display: flex; justify-content: space-between; align-items: center; font-size: 12px; font-weight: 800; color: var(--text-muted); border-bottom: 1px solid var(--card-border); padding-bottom: 8px; }
    .pair-item { background: rgba(15, 23, 42, 0.6); border: 1px solid var(--card-border); border-radius: 10px; padding: 12px; display: flex; flex-direction: column; gap: 8px; }
    .pair-tickets { font-size: 13px; font-weight: 700; font-family: 'JetBrains Mono', monospace; display: flex; justify-content: space-between; align-items: center; }
    .pair-profits { display: flex; justify-content: space-between; align-items: center; font-size: 13px; font-weight: 700; font-family: 'JetBrains Mono', monospace; }
    .pair-net-badge { font-size: 16px; font-weight: 900; font-family: 'JetBrains Mono', monospace; text-align: right; }
  </style>
</head>
<body>
  <div class="container">
    <div class="top-bar">
      <div class="live-badge">
        <div class="live-dot" id="live-dot"></div>
        <span>LIVE <span id="host-ip">127.0.0.1</span></span>
      </div>
      <div class="net-floating" id="net-floating">+$0.00</div>
    </div>

    <div class="target-box">
      <div class="target-title">🎯 TARGET GABUNGAN PLUS (BASKET TP)</div>
      <div class="target-val" id="target-tp">+$31.74</div>
    </div>

    <div class="accounts-grid">
      <div class="account-card">
        <div class="acc-header">MASTER (NON-BONUS)</div>
        <div class="stat-row">
          <div class="stat-label">Login</div>
          <div class="stat-val" id="m-login">100870</div>
        </div>
        <div class="stat-row">
          <div class="stat-label">Equity</div>
          <div class="stat-val" id="m-equity">$0.00</div>
          <div class="stat-sub" id="m-bal">Bal: $0.00 · Cr: $0.00</div>
        </div>
        <div class="stat-row">
          <div class="stat-label">Margin Level</div>
          <div class="stat-val" id="m-margin-level">0.00%</div>
          <div class="stat-sub" id="m-free-margin">Free: $0.00</div>
        </div>
        <div class="stat-row">
          <div class="stat-label">Floating Profit</div>
          <div class="stat-val" id="m-profit">$0.00</div>
        </div>
      </div>

      <div class="account-card">
        <div class="acc-header">SLAVE (BONUS 20%)</div>
        <div class="stat-row">
          <div class="stat-label">Login</div>
          <div class="stat-val" id="s-login">100871</div>
        </div>
        <div class="stat-row">
          <div class="stat-label">Equity</div>
          <div class="stat-val" id="s-equity">$0.00</div>
          <div class="stat-sub" id="s-bal">Bal: $0.00 · Cr: $0.00</div>
        </div>
        <div class="stat-row">
          <div class="stat-label">Margin Level</div>
          <div class="stat-val" id="s-margin-level">0.00%</div>
          <div class="stat-sub" id="s-free-margin">Free: $0.00</div>
        </div>
        <div class="stat-row">
          <div class="stat-label">Floating Profit</div>
          <div class="stat-val" id="s-profit">$0.00</div>
        </div>
      </div>
    </div>

    <div class="pairs-card">
      <div class="pairs-header">
        <span>DETAIL POSISI HEDGE (<span id="pair-count">0</span>)</span>
        <span>POS M/S: <span id="pos-ms">0/0</span></span>
      </div>
      <div id="pairs-list" style="display: flex; flex-direction: column; gap: 10px;">
        <div style="text-align: center; color: var(--text-muted); font-size: 13px; padding: 20px;">
          Menunggu posisi aktif...
        </div>
      </div>
    </div>
  </div>

  <script>
    async function updateDashboard() {
      try {
        const res = await fetch('/api/data');
        const d = await res.json();

        document.getElementById('host-ip').textContent = d.host_ip;
        
        const netEl = document.getElementById('net-floating');
        const netVal = d.net_floating;
        netEl.textContent = (netVal >= 0 ? '+$' : '-$') + Math.abs(netVal).toFixed(2);
        netEl.className = 'net-floating ' + (netVal >= 0 ? 'net-positive' : 'net-negative');

        const m = d.master || {};
        document.getElementById('m-login').textContent = m.login || '100870';
        document.getElementById('m-equity').textContent = '$' + (m.equity || 0).toLocaleString('en-US', {minimumFractionDigits: 2});
        document.getElementById('m-bal').textContent = `Bal: $${(m.balance||0).toFixed(2)} · Cr: $0.00`;
        document.getElementById('m-margin-level').textContent = (m.margin_level || 0).toFixed(1) + '%';
        document.getElementById('m-free-margin').textContent = `Free: $${(m.free_margin||0).toFixed(2)}`;
        
        const mProfEl = document.getElementById('m-profit');
        const mProf = m.profit || 0;
        mProfEl.textContent = (mProf >= 0 ? '+$' : '-$') + Math.abs(mProf).toFixed(2);
        mProfEl.style.color = mProf >= 0 ? 'var(--green)' : 'var(--red)';

        const s = d.slave || {};
        document.getElementById('s-login').textContent = s.login || '100871';
        document.getElementById('s-equity').textContent = '$' + (s.equity || 0).toLocaleString('en-US', {minimumFractionDigits: 2});
        const crVal = (s.equity && s.balance && s.equity > s.balance) ? (s.equity - s.balance).toFixed(2) : '0.00';
        document.getElementById('s-bal').textContent = `Bal: $${(s.balance||0).toFixed(2)} · Cr: $${crVal}`;
        document.getElementById('s-margin-level').textContent = (s.margin_level || 0).toFixed(1) + '%';
        document.getElementById('s-free-margin').textContent = `Free: $${(s.free_margin||0).toFixed(2)}`;
        
        const sProfEl = document.getElementById('s-profit');
        const sProf = s.profit || 0;
        sProfEl.textContent = (sProf >= 0 ? '+$' : '-$') + Math.abs(sProf).toFixed(2);
        sProfEl.style.color = sProf >= 0 ? 'var(--green)' : 'var(--red)';

        const pairs = d.pairs || [];
        document.getElementById('pair-count').textContent = pairs.length;
        document.getElementById('pos-ms').textContent = `${m.count||0}/${s.count||0}`;

        const listEl = document.getElementById('pairs-list');
        if (pairs.length === 0) {
          listEl.innerHTML = '<div style="text-align: center; color: var(--text-muted); font-size: 13px; padding: 20px;">Menunggu posisi aktif...</div>';
        } else {
          listEl.innerHTML = pairs.map(p => {
            const netColor = p.net_profit >= 0 ? 'var(--green)' : 'var(--red)';
            const netSign = p.net_profit >= 0 ? '+$' : '-$';
            const mColor = p.master_profit >= 0 ? 'var(--green)' : 'var(--red)';
            const sColor = p.slave_profit >= 0 ? 'var(--green)' : 'var(--red)';

            return `
              <div class="pair-item">
                <div class="pair-tickets">
                  <span>#${p.master_ticket} S ${p.master_vol}@${p.master_price}</span>
                  <span style="color: var(--text-muted);">⇄</span>
                  <span>#${p.slave_ticket} B ${p.slave_vol}@${p.slave_price}</span>
                </div>
                <div class="pair-profits">
                  <span>M: <span style="color: ${mColor}">${p.master_profit >= 0 ? '+' : ''}$${p.master_profit.toFixed(2)}</span></span>
                  <span>S: <span style="color: ${sColor}">${p.slave_profit >= 0 ? '+' : ''}$${p.slave_profit.toFixed(2)}</span></span>
                </div>
                <div class="pair-net-badge" style="color: ${netColor}">
                  NET: ${netSign}${Math.abs(p.net_profit).toFixed(2)}
                </div>
              </div>
            `;
          }).join('');
        }
      } catch (e) {
        console.error("Dashboard poll error:", e);
      }
    }

    setInterval(updateDashboard, 500);
    updateDashboard();
  </script>
</body>
</html>
"""


class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


class DashboardHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        try:
            if self.path.startswith("/api/data"):
                data = build_dashboard_data()
                body = json.dumps(data).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(body)
            else:
                body = HTML_TEMPLATE.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
        except Exception as e:
            try:
                self.send_error(500, str(e))
            except Exception:
                pass

    def log_message(self, format, *args):
        return


def start_cloudflared():
    cloudflared_bin = os.path.join(os.path.dirname(__file__), "cloudflared.exe")
    if not os.path.isfile(cloudflared_bin):
        # Auto-download if missing
        try:
            import urllib.request
            print("[*] Mengunduh cloudflared.exe...")
            urllib.request.urlretrieve(
                "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe",
                cloudflared_bin
            )
        except Exception as e:
            print(f"[!] Gagal unduh cloudflared: {e}")
            return

    def run_cf():
        try:
            proc = subprocess.Popen(
                [cloudflared_bin, "tunnel", "--url", f"http://127.0.0.1:{PORT}"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="ignore"
            )
            for line in iter(proc.stderr.readline, ""):
                match = re.search(r"https://[a-zA-Z0-9-]+\.trycloudflare\.com", line)
                if match:
                    url = match.group(0)
                    print("\n" + "=" * 65)
                    print(f" 🌐 LINK KHUSUS NOTEBOOK / MAC ANDA (KLIK / BUKA INI):")
                    print(f" 👉 {url}")
                    print("=" * 65 + "\n")
        except Exception as e:
            print(f"[!] Error tunnel: {e}")

    t = threading.Thread(target=run_cf, daemon=True)
    t.start()


def main():
    start_cloudflared()
    server = ThreadingHTTPServer(("0.0.0.0", PORT), DashboardHandler)
    print(f"\n" + "=" * 65)
    print(f" 🚀 LIVE VISUAL DASHBOARD BERJALAN!")
    print(f" 👉 Akses Lokal VPS   : http://localhost:{PORT}")
    print(f" 👉 Shared Folder MT5 : {COMMON_DIR}")
    print(f"=" * 65)
    print(f" ⏳ Menyiapkan Public Link untuk Notebook Anda...\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Server dihentikan.")


if __name__ == "__main__":
    main()
