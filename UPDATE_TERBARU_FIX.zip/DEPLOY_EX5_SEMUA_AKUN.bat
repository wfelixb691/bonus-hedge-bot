@echo off
setlocal enabledelayedexpansion
title 1-CLICK DEPLOY EX5 KE SEMUA AKUN / TERMINAL MT5
color 0B
cd /d "%~dp0"

echo ===============================================================================
echo     1-CLICK FAST DEPLOYER - BONUS HEDGE BOT EX5 KE SEMUA TERMINAL MT5
echo ===============================================================================
echo.

:: 1. Verifikasi File .ex5
if not exist "%~dp0BonusHedge_Master.ex5" (
    echo [!] BonusHedge_Master.ex5 belum ditemukan!
    echo [*] Mencoba kompilasi otomatis lewat auto_compile.bat...
    call "%~dp0auto_compile.bat"
)

if not exist "%~dp0BonusHedge_Master.ex5" (
    echo [ERROR] File BonusHedge_Master.ex5 tidak ditemukan. Kompilasi gagal atau belum selesai.
    pause
    exit /b 1
)

echo [OK] File EX5 Terdeteksi:
echo      - BonusHedge_Master.ex5
echo      - BonusHedge_Slave.ex5
echo.

:: 2. Scanning dan Copy ke Semua Data Folder MT5
echo [*] Memindai seluruh folder data MetaTrader 5...
echo -------------------------------------------------------------------------------
set "COUNT=0"

:: A. Cek folder Roaming (Standar MT5 untuk multi-terminal)
set "ROAMING_DIR=%APPDATA%\MetaQuotes\Terminal"
if exist "!ROAMING_DIR!" (
    for /d %%T in ("!ROAMING_DIR!\*") do (
        if exist "%%T\MQL5\Experts" (
            set /a COUNT+=1
            echo [!COUNT!] Menyalin ke AppData: %%~nxT
            copy /Y "%~dp0BonusHedge_Master*.ex5" "%%T\MQL5\Experts\" >nul 2>nul
            copy /Y "%~dp0BonusHedge_Slave*.ex5" "%%T\MQL5\Experts\" >nul 2>nul
            
            :: Opsional: Copy source .mq5 jika ingin bisa view/debug di MetaEditor masing-masing
            copy /Y "%~dp0BonusHedge_Master*.mq5" "%%T\MQL5\Experts\" >nul 2>nul
            copy /Y "%~dp0BonusHedge_Slave*.mq5" "%%T\MQL5\Experts\" >nul 2>nul

            :: Copy Presets .set jika ada
            if not exist "%%T\MQL5\Presets" mkdir "%%T\MQL5\Presets"
            if exist "%~dp0Pair1_Master1.set" copy /Y "%~dp0Pair1_Master1.set" "%%T\MQL5\Presets\" >nul 2>nul
            if exist "%~dp0Pair1_Slave2.set" copy /Y "%~dp0Pair1_Slave2.set" "%%T\MQL5\Presets\" >nul 2>nul
            if exist "%~dp0Pair2_Master3.set" copy /Y "%~dp0Pair2_Master3.set" "%%T\MQL5\Presets\" >nul 2>nul
            if exist "%~dp0Pair2_Slave4.set" copy /Y "%~dp0Pair2_Slave4.set" "%%T\MQL5\Presets\" >nul 2>nul
        )
    )
)

:: B. Cek mode Portable / Direktori Program Files
for /d %%P in ("C:\Program Files\*MetaTrader*") do (
    if exist "%%P\MQL5\Experts" (
        set /a COUNT+=1
        echo [!COUNT!] Menyalin ke Portable: %%~nxP
        copy /Y "%~dp0BonusHedge_Master*.ex5" "%%P\MQL5\Experts\" >nul 2>nul
        copy /Y "%~dp0BonusHedge_Slave*.ex5" "%%P\MQL5\Experts\" >nul 2>nul
        copy /Y "%~dp0BonusHedge_Master*.mq5" "%%P\MQL5\Experts\" >nul 2>nul
        copy /Y "%~dp0BonusHedge_Slave*.mq5" "%%P\MQL5\Experts\" >nul 2>nul
        
        if not exist "%%P\MQL5\Presets" mkdir "%%P\MQL5\Presets"
        if exist "%~dp0Pair1_Master1.set" copy /Y "%~dp0Pair1_Master1.set" "%%P\MQL5\Presets\" >nul 2>nul
        if exist "%~dp0Pair1_Slave2.set" copy /Y "%~dp0Pair1_Slave2.set" "%%P\MQL5\Presets\" >nul 2>nul
        if exist "%~dp0Pair2_Master3.set" copy /Y "%~dp0Pair2_Master3.set" "%%P\MQL5\Presets\" >nul 2>nul
        if exist "%~dp0Pair2_Slave4.set" copy /Y "%~dp0Pair2_Slave4.set" "%%P\MQL5\Presets\" >nul 2>nul
    )
)

for /d %%P in ("C:\Program Files\Prime Codex*") do (
    if exist "%%P\MQL5\Experts" (
        set /a COUNT+=1
        echo [!COUNT!] Menyalin ke Portable: %%~nxP
        copy /Y "%~dp0BonusHedge_Master*.ex5" "%%P\MQL5\Experts\" >nul 2>nul
        copy /Y "%~dp0BonusHedge_Slave*.ex5" "%%P\MQL5\Experts\" >nul 2>nul
        copy /Y "%~dp0BonusHedge_Master*.mq5" "%%P\MQL5\Experts\" >nul 2>nul
        copy /Y "%~dp0BonusHedge_Slave*.mq5" "%%P\MQL5\Experts\" >nul 2>nul
        
        if not exist "%%P\MQL5\Presets" mkdir "%%P\MQL5\Presets"
        if exist "%~dp0Pair1_Master1.set" copy /Y "%~dp0Pair1_Master1.set" "%%P\MQL5\Presets\" >nul 2>nul
        if exist "%~dp0Pair1_Slave2.set" copy /Y "%~dp0Pair1_Slave2.set" "%%P\MQL5\Presets\" >nul 2>nul
        if exist "%~dp0Pair2_Master3.set" copy /Y "%~dp0Pair2_Master3.set" "%%P\MQL5\Presets\" >nul 2>nul
        if exist "%~dp0Pair2_Slave4.set" copy /Y "%~dp0Pair2_Slave4.set" "%%P\MQL5\Presets\" >nul 2>nul
    )
)

echo -------------------------------------------------------------------------------
if !COUNT! gtr 0 (
    echo [SUKSES] Berhasil mendistribusikan .ex5 ke !COUNT! terminal MT5!
) else (
    echo [PERINGATAN] Tidak ditemukan folder Terminal MT5 standar di sistem ini.
    echo Pastikan MT5 pernah dibuka minimal sekali di PC / VPS ini.
)
echo.

:: 3. Pilihan Refresh / Flush Memory
echo ===============================================================================
echo   CARA AGAR EA TERBARU AKTIF DI CHART YANG SEDANG JALAN:
echo ===============================================================================
echo   Opsi 1: RESTART OTOMATIS SEMUA TERMINAL MT5 (Disarankan agar 100%% memuat .ex5 baru)
echo   Opsi 2: HOT RELOAD MANUAL (Di MT5: Klik kanan 'Expert Advisors' -^> 'Refresh',
echo           lalu ubah timeframe chart M1 -^> M5 -^> M1)
echo.

set /p RESTART_CHOICE="Apakah Anda ingin restart semua terminal MT5 sekarang? (Y/N): "
if /i "%RESTART_CHOICE%"=="Y" (
    echo.
    echo [*] Me-restart semua terminal MT5 yang sedang aktif...
    powershell -NoProfile -Command "$paths = Get-Process terminal64 -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Path -Unique; if($paths) { Stop-Process -Name terminal64 -Force; Start-Sleep -Seconds 3; foreach($p in $paths) { Start-Process $p }; Write-Host '>>> [BERHASIL] Seluruh MT5 telah di-restart dan memuat versi .ex5 terbaru!' -ForegroundColor Green } else { Write-Host '[INFO] Tidak ada proses terminal64.exe yang sedang berjalan.' -ForegroundColor Yellow }"
) else (
    echo.
    echo [INFO] Terminal tidak direstart. Silakan klik kanan 'Refresh' di Navigator MT5 masing-masing.
)

echo.
echo ===============================================================================
echo   DEPLOYMENT SELESAI!
echo ===============================================================================
pause
