//+------------------------------------------------------------------+
//|                                           BonusHedge_Master.mq5  |
//|                         All-in-One Dual-MT5 Bonus Hedging Master |
//|                                  Copyright 2026, Advanced Bot EA |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Advanced Bot EA"
#property link      "https://www.mql5.com"
#property version   "1.20"
#property strict

#include <Trade\Trade.mqh>

//--- Input Parameters
input group "=== GRID STRATEGY PARAMETERS ==="
input string   InpSymbol            = "XAUUSD";      // Trading Symbol
input double   InpInitialLot        = 0.10;          // Base Lot Size (e.g. 0.10 or 0.30)
input bool     InpAutoScaleLot      = false;         // Auto-Scale Lot by Balance (false = Fixed Lot)
input double   InpGridStepPoints    = 2000.0;        // Grid Step Points ($20.00 on Gold)
input int      InpMaxLayers         = 10;            // Maximum Grid Layers
input double   InpBasketTPDollars   = 31.74;         // Master Basket TP ($ Total)
input double   InpSpreadBufferUSD   = 10.0;          // Spread & Slippage Buffer (USD)
input ulong    InpMagic             = 888111;        // Master Magic Number
input string   InpCommentPrefix     = "GRID_S";      // Comment Prefix for Layers

input group "=== MARGIN & CIRCUIT BREAKER (CROSS-CHECK) ==="
input double   InpMinMarginLevel    = 50.0;          // Min Margin Level % (Stop opening if below)
input double   InpMinFreeMargin     = 10.0;          // Min Free Margin $ (Stop opening if below)
input bool     InpHarvestOnSlaveMC  = true;          // Auto Close Master if Slave hits Margin Call/StopOut

input group "=== TELEGRAM LIVE REPORT SETTINGS ==="
input bool     InpEnableTelegram       = true;                    // Enable Telegram Live Alerts
input string   InpTelegramBotToken     = "";                      // Telegram Bot Token (from @BotFather)
input string   InpTelegramChatID       = "";                      // Telegram Chat ID (from @userinfobot)
input int      InpTelegramIntervalMin  = 5;                       // Periodic Report Interval (Minutes)

input group "=== CLOUD WEB DASHBOARD SETTINGS ==="
input bool     InpEnableWebDashboard   = false;                               // Enable Live Web Dashboard
input string   InpWebDashboardUrl      = "http://localhost:3000/api/telemetry"; // Cloud Telemetry API URL
input int      InpWebIntervalSec       = 2;                                   // Web Refresh Interval (Seconds)

input group "=== BRIDGE & COMM SETTINGS ==="
input string   InpMasterFile        = "bonus_hedge_master.dat";   // Master State File (FILE_COMMON)
input string   InpSlaveFile         = "bonus_hedge_slave.dat";    // Slave State File (FILE_COMMON)
input string   InpCommandFile       = "bonus_hedge_command.dat";  // Command File (FILE_COMMON)
input int      InpTimerMS           = 50;                         // Sync Interval in ms

//--- Global Objects
CTrade         m_trade;
datetime       m_last_order_time    = 0;
datetime       m_last_telegram_time = 0;
datetime       m_last_web_time      = 0;
datetime       m_closing_lock_until = 0;
string         m_symbol             = "";
double         m_point              = 0.01;
int            m_digits             = 2;
bool           m_closing_active     = false;


// Slave Telemetry Snapshot
struct SlavePosInfo
{
   ulong  ticket;
   int    type;
   double volume;
   double price_open;
   double profit;
   string comment;
};

SlavePosInfo   m_slave_positions[];
long           m_slave_time         = 0;
long           m_slave_login        = 0;
double         m_slave_equity       = 0.0;
double         m_slave_balance      = 0.0;
double         m_slave_free_margin  = 0.0;
double         m_slave_margin_level = 0.0;
double         m_slave_profit       = 0.0;
int            m_slave_pos_count    = 0;
bool           m_slave_online       = false;
long           m_slave_last_counter = -1;
datetime       m_slave_last_seen    = 0;

//--- Forward Declarations
void   ReadSlaveState();
void   CheckIncomingCommands();
bool   CheckSlaveLiquidationHarvest();
void   ManageGrid();
void   CloseAllMasterPositions();
void   BroadcastMasterState();
void   SendCommandToSlave(string cmd);
void   UpdateDashboard();
string UrlEncode(string text);
void   SendTelegramMessage(string raw_message);
void   SendWebTelemetry();
void   CheckSlaveTimeout();

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
   m_symbol = (InpSymbol == "" || InpSymbol == "0") ? _Symbol : InpSymbol;
   if(!SymbolSelect(m_symbol, true)) m_symbol = _Symbol;

   m_point  = SymbolInfoDouble(m_symbol, SYMBOL_POINT);
   m_digits = (int)SymbolInfoInteger(m_symbol, SYMBOL_DIGITS);
   if(m_point <= 0) m_point = 0.01;

   m_trade.SetExpertMagicNumber(InpMagic);
   m_trade.SetDeviationInPoints(50);
   m_trade.SetTypeFillingBySymbol(m_symbol);

   FileDelete(InpCommandFile, FILE_COMMON);

   EventSetMillisecondTimer(InpTimerMS);
   Print("🟢 [BonusHedge_Master] Initialized on ", m_symbol, " (Magic: ", InpMagic, ")");

   // Immediate startup test ping to Telegram
   if(InpEnableTelegram && StringLen(InpTelegramBotToken) > 0 && StringLen(InpTelegramChatID) > 0)
   {
      SendTelegramMessage("🟢 <b>[DUAL-MT5 BONUS HEDGING AKTIF]</b>\n" +
                          "👑 Akun Master: <b>" + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "</b>\n" +
                          "📊 Symbol: <b>" + m_symbol + "</b> | Base Lot: <b>" + DoubleToString(InpInitialLot, 2) + "L</b>\n" +
                          "⏱️ Laporan live akan dikirim setiap " + IntegerToString(InpTelegramIntervalMin) + " menit.");
   }

   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();
   FileDelete(InpMasterFile, FILE_COMMON);
   Comment("");
}

//+------------------------------------------------------------------+
//| Timer event function                                             |
//+------------------------------------------------------------------+
void OnTimer()
{
   // 1. Read Slave Telemetry (Two-Way Communication)
   ReadSlaveState();

   // 2. Check for incoming commands (e.g. CLOSE_ALL from Slave)
   CheckIncomingCommands();

   // 3. Always Broadcast Master State so Slave is NEVER left with stale data
   BroadcastMasterState();

   // 4. Update On-Screen Dashboard & Cloud Web Telemetry
   UpdateDashboard();
   SendWebTelemetry();

   // 5. CHECK IF ALGO TRADING IS ALLOWED BY USER IN MT5
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED))
   {
      Comment("\n  ⚠️ [BonusHedge_Master] ALGO TRADING IS DISABLED IN MT5!\n" +
              "  Klik tombol 'Algo Trading' di toolbar atas MT5 agar robot bisa bekerja.");
      return;
   }

   // 6. Check if Slave was liquidated / hit MC -> Harvest Master Profit
   if(InpHarvestOnSlaveMC && CheckSlaveLiquidationHarvest())
      return;

   // 7. Manage Grid Logic (with pre-trade margin verification)
   if(!m_closing_active)
      ManageGrid();
}

//+------------------------------------------------------------------+
//| Read Slave state from FILE_COMMON (Two-Way Telemetry)            |
//| v2 protocol: magic|version|counter|login|equity|balance|free|ml| |
//|              profit|count|positions...                           |
//| Partial/invalid reads KEEP the last good snapshot - destructive  |
//| actions require SUSTAINED state, never a single racy read.       |
//+------------------------------------------------------------------+
void ReadSlaveState()
{
   if(!FileIsExist(InpSlaveFile, FILE_COMMON))
   {
      CheckSlaveTimeout();
      return;
   }

   int file_handle = FileOpen(InpSlaveFile, FILE_READ|FILE_BIN|FILE_COMMON|FILE_SHARE_READ|FILE_SHARE_WRITE);
   if(file_handle == INVALID_HANDLE)
   {
      CheckSlaveTimeout();
      return;
   }

   ResetLastError();
   long new_magic   = FileReadLong(file_handle);
   bool ok          = (GetLastError() == 0);
   long new_version = 0;
   long new_counter = 0;
   if(ok) { ResetLastError(); new_version = FileReadLong(file_handle); ok = (GetLastError() == 0); }
   if(ok) { ResetLastError(); new_counter = FileReadLong(file_handle); ok = (GetLastError() == 0); }

   long   new_login       = 0;
   double new_equity      = 0.0;
   double new_balance     = 0.0;
   double new_free_margin = 0.0;
   double new_margin_lvl  = 0.0;
   double new_profit      = 0.0;
   int    new_pos_count   = 0;

   if(ok) { ResetLastError(); new_login       = FileReadLong(file_handle);   ok = (GetLastError() == 0); }
   if(ok) { ResetLastError(); new_equity      = FileReadDouble(file_handle); ok = (GetLastError() == 0); }
   if(ok) { ResetLastError(); new_balance     = FileReadDouble(file_handle); ok = (GetLastError() == 0); }
   if(ok) { ResetLastError(); new_free_margin = FileReadDouble(file_handle); ok = (GetLastError() == 0); }
   if(ok) { ResetLastError(); new_margin_lvl  = FileReadDouble(file_handle); ok = (GetLastError() == 0); }
   if(ok) { ResetLastError(); new_profit      = FileReadDouble(file_handle); ok = (GetLastError() == 0); }
   if(ok) { ResetLastError(); new_pos_count   = FileReadInteger(file_handle); ok = (GetLastError() == 0); }

   // Baca ke array paralel primitif (struct ber-string tidak boleh lokal di MQL5)
   ulong  t_tickets[];
   int    t_types[];
   double t_volumes[], t_prices[], t_profits[];
   string t_comments[];
   ArrayResize(t_tickets, 0);
   ArrayResize(t_types, 0);
   ArrayResize(t_volumes, 0);
   ArrayResize(t_prices, 0);
   ArrayResize(t_profits, 0);
   ArrayResize(t_comments, 0);
   if(ok && new_pos_count >= 0 && new_pos_count <= 100)
   {
      ArrayResize(t_tickets,  new_pos_count);
      ArrayResize(t_types,    new_pos_count);
      ArrayResize(t_volumes,  new_pos_count);
      ArrayResize(t_prices,   new_pos_count);
      ArrayResize(t_profits,  new_pos_count);
      ArrayResize(t_comments, new_pos_count);
      for(int i = 0; i < new_pos_count; i++)
      {
         ResetLastError();
         t_tickets[i] = (ulong)FileReadLong(file_handle);
         ok = (GetLastError() == 0); if(!ok) break;
         ResetLastError();
         t_types[i] = FileReadInteger(file_handle);
         ok = (GetLastError() == 0); if(!ok) break;
         ResetLastError();
         t_volumes[i] = FileReadDouble(file_handle);
         ok = (GetLastError() == 0); if(!ok) break;
         ResetLastError();
         t_prices[i] = FileReadDouble(file_handle);
         ok = (GetLastError() == 0); if(!ok) break;
         ResetLastError();
         t_profits[i] = FileReadDouble(file_handle);
         ok = (GetLastError() == 0); if(!ok) break;
         ResetLastError();
         int clen = FileReadInteger(file_handle);
         ok = (GetLastError() == 0); if(!ok) break;
         if(clen > 0 && clen < 256)
            t_comments[i] = FileReadString(file_handle, clen);
         else
            t_comments[i] = "";
      }
      if(!ok)
      {
         ArrayResize(t_tickets,  0);
         ArrayResize(t_types,    0);
         ArrayResize(t_volumes,  0);
         ArrayResize(t_prices,   0);
         ArrayResize(t_profits,  0);
         ArrayResize(t_comments, 0);
      }
   }
   else if(ok)
   {
      ok = false; // pos_count di luar rentang = payload tidak valid
   }

   FileClose(file_handle);

   // Payload tidak valid / versi beda: jaga snapshot terakhir yang bagus
   if(!ok || new_magic != 0x42484246 || new_version != 2)
   {
      CheckSlaveTimeout();
      return;
   }

   // Heartbeat: counter harus maju; nilai sama = writer berhenti menulis
   if(new_counter == m_slave_last_counter)
   {
      CheckSlaveTimeout();
      return;
   }

   m_slave_last_counter = new_counter;
   m_slave_time         = new_counter;
   m_slave_login        = new_login;
   m_slave_equity       = new_equity;
   m_slave_balance      = new_balance;
   m_slave_free_margin  = new_free_margin;
   m_slave_margin_level = new_margin_lvl;
   m_slave_profit       = new_profit;
   m_slave_pos_count    = new_pos_count;
   ArrayResize(m_slave_positions, new_pos_count);
   for(int i = 0; i < new_pos_count; i++)
   {
      m_slave_positions[i].ticket     = t_tickets[i];
      m_slave_positions[i].type       = t_types[i];
      m_slave_positions[i].volume     = t_volumes[i];
      m_slave_positions[i].price_open = t_prices[i];
      m_slave_positions[i].profit     = t_profits[i];
      m_slave_positions[i].comment    = t_comments[i];
   }
   m_slave_last_seen    = TimeLocal();
   m_slave_online       = true;
}

//+------------------------------------------------------------------+
//| Rate-independent offline detection (30 detik grace)              |
//+------------------------------------------------------------------+
void CheckSlaveTimeout()
{
   if(m_slave_last_seen > 0 && (TimeLocal() - m_slave_last_seen <= 30))
      return; // masih dalam grace: pertahankan snapshot & flag online
   m_slave_online = false;
}

//+------------------------------------------------------------------+
//| Check if Slave got closed / stopped out / liquidated             |
//| IRONCLAD SAFETY: Trigger ONLY when Slave is genuinely MC/Liquidated|
//+------------------------------------------------------------------+
bool CheckSlaveLiquidationHarvest()
{
   if(!m_slave_online || m_closing_active) return false;

   // Hanya aktifkan liquidation harvest jika akun Slave benar-benar hancur / MC (Equity < $10 atau Margin Level < 20%)!
   if(m_slave_equity > 0 && (m_slave_equity < 10.0 || (m_slave_margin_level > 0 && m_slave_margin_level < 20.0)))
   {
      Print("🚨 [CRITICAL HEDGE SAFETY] Slave account (", m_slave_login,
            ") TERKENA MARGIN CALL / LIQUIDASI! Menutup semua posisi Master untuk panen profit!");
      m_closing_active = true;
      m_closing_lock_until = TimeCurrent() + 4;
      CloseAllMasterPositions();
      m_closing_active = false;
      m_last_order_time = TimeCurrent();
      return true;
   }

   return false;
}

//+------------------------------------------------------------------+
//| Main Grid Strategy Execution                                     |
//+------------------------------------------------------------------+
void ManageGrid()
{
   int    total_positions = 0;
   double total_profit    = 0.0;
   double min_price       = DBL_MAX;
   double max_price       = 0.0;

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0
         && (StringCompare(PositionGetString(POSITION_SYMBOL), m_symbol, false) == 0 || StringCompare(PositionGetString(POSITION_SYMBOL), _Symbol, false) == 0)
         && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
      {
         total_positions++;
         total_profit += PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
         double open_p = PositionGetDouble(POSITION_PRICE_OPEN);
         if(open_p < min_price) min_price = open_p;
         if(open_p > max_price) max_price = open_p;
      }
   }

   // Auto-calculate Basket TP proportional to Initial Lot (Base: $31.74 per 0.10 lot) + Spread Buffer
   double effective_lot = InpInitialLot;
   double effective_basket_tp = ((InpInitialLot / 0.10) * 31.74) + InpSpreadBufferUSD;
   if(InpBasketTPDollars > 0 && InpBasketTPDollars != 31.74)
   {
      effective_basket_tp = InpBasketTPDollars + InpSpreadBufferUSD; // Use custom if user explicitly typed a custom amount
   }

   // --- CHECK COMBINED NET PROFIT (MASTER + SLAVE GABUNGAN PLUS) ---
   // Wajib gabungan Master + Slave agar 100% meng-cover semua spread dan komisi!
   double combined_net_profit = total_profit + (m_slave_online ? m_slave_profit : 0.0);

   if(total_positions > 0 && effective_basket_tp > 0 && combined_net_profit >= effective_basket_tp)
   {
      Print("🎉 [COMBINED NET TP TRIGGERED] Total Gabungan (Master+Slave): $", DoubleToString(combined_net_profit, 2),
            " >= Target $", DoubleToString(effective_basket_tp, 2), " (Semua Spread Ter-Cover!)");
      m_closing_active = true;
      m_closing_lock_until = TimeCurrent() + 4; // 4-second closing lock
      CloseAllMasterPositions();
      SendCommandToSlave("CLOSE_ALL");
      m_closing_active = false;
      m_last_order_time = TimeCurrent();
      return;
   }


   // --- PRE-TRADE MARGIN CHECK (SELF & SLAVE) ---
   double my_free_margin  = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   double my_margin_level = AccountInfoDouble(ACCOUNT_MARGIN_LEVEL);

   // Do not open if Master's margin is critical
   if(my_free_margin < InpMinFreeMargin || (my_margin_level > 0 && my_margin_level < InpMinMarginLevel))
   {
      return; // Hold off, margin critical
   }

   // Do not open if Slave's margin is critical or Slave is offline
   if(total_positions > 0 && m_slave_online)
   {
      if(m_slave_free_margin < InpMinFreeMargin || (m_slave_margin_level > 0 && m_slave_margin_level < InpMinMarginLevel))
      {
         return; // Hold off, Slave cannot support another hedge layer
      }
   }

   // Cooldown between orders (10 seconds) and Closing Lock guard
   if(TimeCurrent() < m_closing_lock_until) return;
   if(TimeCurrent() - m_last_order_time < 10) return;

   MqlTick tick;
   if(!SymbolInfoTick(m_symbol, tick) || tick.bid <= 0) return;

   // --- LAYER 1 (INITIAL ORDER) ---
   if(total_positions == 0)
   {
      m_last_order_time = TimeCurrent(); // Update cooldown immediately to prevent rapid-fire loops
      string comment = InpCommentPrefix + "1";
      if(m_trade.Sell(effective_lot, m_symbol, tick.bid, 0, 0, comment))
      {
         Print("✅ [MASTER OPEN INITIAL] Layer 1: SELL ", effective_lot, "L @ ", tick.bid, " (", comment, ")");
      }
      return;
   }

   // --- NEXT LAYERS (GRID STEPS) ---
   if(total_positions < InpMaxLayers)
   {
      // SAFETY CHECK: Jangan pernah buka Layer berikutnya jika Slave belum berhasil meng-hedge layer sebelumnya!
      if(m_slave_online && m_slave_pos_count < total_positions)
      {
         return; // Hold off, tunggu Slave selesai hedge
      }

      double step_distance = InpGridStepPoints * m_point;
      bool should_open = false;

      if(min_price < DBL_MAX)
      {
         if((tick.bid - max_price) >= step_distance) should_open = true;
         if((min_price - tick.bid) >= step_distance) should_open = true;
      }

      if(should_open)
      {
         m_last_order_time = TimeCurrent(); // Update cooldown immediately
         string comment = InpCommentPrefix + IntegerToString(total_positions + 1);
         if(m_trade.Sell(effective_lot, m_symbol, tick.bid, 0, 0, comment))
         {
            Print("✅ [MASTER OPEN NEXT LAYER] Layer ", (total_positions + 1), ": SELL ",
                  effective_lot, "L @ ", tick.bid, " (", comment, ")");
         }
      }
   }
}

//+------------------------------------------------------------------+
//| Close all Master grid positions safely                           |
//+------------------------------------------------------------------+
void CloseAllMasterPositions()
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0
         && (StringCompare(PositionGetString(POSITION_SYMBOL), m_symbol, false) == 0 || StringCompare(PositionGetString(POSITION_SYMBOL), _Symbol, false) == 0)
         && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
      {
         m_trade.PositionClose(ticket);
      }
   }
}

//+------------------------------------------------------------------+
//| Broadcast Master State via FILE_COMMON (Includes Margin Data)    |
//+------------------------------------------------------------------+
void BroadcastMasterState()
{
   int count = 0;
   double total_prof = 0.0;
   ulong  tickets[];
   int    types[];
   double volumes[], prices[], profits[];
   string comments[];

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0
         && (StringCompare(PositionGetString(POSITION_SYMBOL), m_symbol, false) == 0 || StringCompare(PositionGetString(POSITION_SYMBOL), _Symbol, false) == 0)
         && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
      {
         ArrayResize(tickets,  count + 1);
         ArrayResize(types,    count + 1);
         ArrayResize(volumes,  count + 1);
         ArrayResize(prices,   count + 1);
         ArrayResize(profits,  count + 1);
         ArrayResize(comments, count + 1);

         tickets[count]  = ticket;
         types[count]    = (int)PositionGetInteger(POSITION_TYPE);
         volumes[count]  = PositionGetDouble(POSITION_VOLUME);
         prices[count]   = PositionGetDouble(POSITION_PRICE_OPEN);
         profits[count]  = PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
         comments[count] = PositionGetString(POSITION_COMMENT);
         total_prof     += profits[count];
         count++;
      }
   }

   int file_handle = FileOpen(InpMasterFile, FILE_WRITE|FILE_BIN|FILE_COMMON|FILE_SHARE_READ|FILE_SHARE_WRITE);
   if(file_handle == INVALID_HANDLE) return;

   static long s_broadcast_counter = 0;
   s_broadcast_counter++;
   FileWriteLong(file_handle, 0x42484246);         // magic "BHBF"
   FileWriteLong(file_handle, 2);                  // protocol version
   FileWriteLong(file_handle, s_broadcast_counter);// heartbeat counter
   FileWriteLong(file_handle, AccountInfoInteger(ACCOUNT_LOGIN));
   FileWriteDouble(file_handle, AccountInfoDouble(ACCOUNT_EQUITY));
   FileWriteDouble(file_handle, AccountInfoDouble(ACCOUNT_BALANCE));
   FileWriteDouble(file_handle, AccountInfoDouble(ACCOUNT_MARGIN_FREE));
   FileWriteDouble(file_handle, AccountInfoDouble(ACCOUNT_MARGIN_LEVEL));
   FileWriteDouble(file_handle, total_prof);
   FileWriteInteger(file_handle, count);

   for(int i = 0; i < count; i++)
   {
      FileWriteLong(file_handle, (long)tickets[i]);
      FileWriteInteger(file_handle, types[i]);
      FileWriteDouble(file_handle, volumes[i]);
      FileWriteDouble(file_handle, prices[i]);
      FileWriteDouble(file_handle, profits[i]);
      int clen = StringLen(comments[i]);
      FileWriteInteger(file_handle, clen);
      if(clen > 0) FileWriteString(file_handle, comments[i], clen);
   }

   FileFlush(file_handle);
   FileClose(file_handle);
}

//+------------------------------------------------------------------+
//| Check incoming commands from Slave                               |
//+------------------------------------------------------------------+
void CheckIncomingCommands()
{
   if(!FileIsExist(InpCommandFile, FILE_COMMON)) return;

   int file_handle = FileOpen(InpCommandFile, FILE_READ|FILE_BIN|FILE_COMMON|FILE_SHARE_READ|FILE_SHARE_WRITE);
   if(file_handle == INVALID_HANDLE) return;

   int clen = FileReadInteger(file_handle);
   string cmd = "";
   if(clen > 0) cmd = FileReadString(file_handle, clen);
   FileClose(file_handle);

   FileDelete(InpCommandFile, FILE_COMMON);

   if(cmd == "CLOSE_ALL" && !m_closing_active)
   {
      Print("🚨 [MASTER] Received CLOSE_ALL from Slave! Closing all positions.");
      m_closing_active = true;
      m_closing_lock_until = TimeCurrent() + 4;
      CloseAllMasterPositions();
      m_closing_active = false;
      m_last_order_time = TimeCurrent();
   }
}

void SendCommandToSlave(string cmd)
{
   int file_handle = FileOpen(InpCommandFile, FILE_WRITE|FILE_BIN|FILE_COMMON|FILE_SHARE_READ|FILE_SHARE_WRITE);
   if(file_handle != INVALID_HANDLE)
   {
      int clen = StringLen(cmd);
      FileWriteInteger(file_handle, clen);
      if(clen > 0) FileWriteString(file_handle, cmd, clen);
      FileFlush(file_handle);
      FileClose(file_handle);
   }
}

//+------------------------------------------------------------------+
//| Draw On-Screen Dashboard                                         |
//+------------------------------------------------------------------+
void UpdateDashboard()
{
   int    total_positions = 0;
   double total_profit    = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0
         && PositionGetString(POSITION_SYMBOL) == m_symbol
         && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
      {
         total_positions++;
         total_profit += PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
      }
   }

   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double basket_tp = InpAutoScaleLot ? (balance / 1000.0) * InpBasketTPDollars : InpBasketTPDollars;

   string slave_info = m_slave_online ?
      ("Login: " + IntegerToString(m_slave_login) + " | Free: $" + DoubleToString(m_slave_free_margin, 2) + " (" + DoubleToString(m_slave_margin_level, 1) + "%)") :
      "OFFLINE / Not Connected";

   string text = "\n" +
      "  ╔════════════════════════════════════════════════════════════════╗\n" +
      "  ║   ⚡ DUAL-MT5 BONUS HEDGING - MASTER ENGINE (100870)          ║\n" +
      "  ╠════════════════════════════════════════════════════════════════╣\n" +
      "    Symbol          : " + m_symbol + "\n" +
      "    Account Login   : " + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "\n" +
      "    Balance / Equity: $" + DoubleToString(balance, 2) + " / $" + DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY), 2) + "\n" +
      "    Free Margin     : $" + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_FREE), 2) + " (" + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_LEVEL), 1) + "%)\n" +
      "    Active Layers   : " + IntegerToString(total_positions) + " / " + IntegerToString(InpMaxLayers) + "\n" +
      "    Master Floating : $" + DoubleToString(total_profit, 2) + "\n" +
      "    Target Basket TP: $" + DoubleToString(basket_tp, 2) + "\n" +
      "  ────────────────────────────────────────────────────────────────\n" +
      "    🔗 SLAVE TELEMETRY: " + slave_info + "\n" +
      "    Status          : " + (total_positions > 0 ? "✅ GRID ACTIVE (SYNC 50ms)" : "⏳ IDLE - Waiting") + "\n" +
      "  ╚════════════════════════════════════════════════════════════════╝\n";

   Comment(text);

   // Periodic Telegram Snapshot
   if(InpEnableTelegram && StringLen(InpTelegramBotToken) > 0 && StringLen(InpTelegramChatID) > 0)
   {
      if(TimeCurrent() - m_last_telegram_time >= InpTelegramIntervalMin * 60)
      {
         // Build Master position details
         string master_pos_details = "";
         for(int i = PositionsTotal() - 1; i >= 0; i--)
         {
            ulong t = PositionGetTicket(i);
            if(t > 0 && (StringCompare(PositionGetString(POSITION_SYMBOL), m_symbol, false) == 0 || StringCompare(PositionGetString(POSITION_SYMBOL), _Symbol, false) == 0) && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
            {
               double p_prof = PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
               string p_sign = (p_prof >= 0) ? "+$" : "-$";
               string p_type = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_SELL) ? "SELL" : "BUY";
               master_pos_details += "   └ #" + IntegerToString(t) + " " + p_type + " " + DoubleToString(PositionGetDouble(POSITION_VOLUME), 2) + "L @ " + DoubleToString(PositionGetDouble(POSITION_PRICE_OPEN), 2) + " (" + p_sign + DoubleToString(MathAbs(p_prof), 2) + ")\n";
            }
         }
         if(master_pos_details == "") master_pos_details = "   └ (Tidak ada posisi aktif)\n";

         // Build Slave position details
         string slave_pos_details = "";
         for(int i = 0; i < m_slave_pos_count; i++)
         {
            string s_type = (m_slave_positions[i].type == 1) ? "SELL" : "BUY";
            string s_sign = (m_slave_positions[i].profit >= 0) ? "+$" : "-$";
            slave_pos_details += "   └ #" + IntegerToString(m_slave_positions[i].ticket) + " " + s_type + " " + DoubleToString(m_slave_positions[i].volume, 2) + "L @ " + DoubleToString(m_slave_positions[i].price_open, 2) + " (" + s_sign + DoubleToString(MathAbs(m_slave_positions[i].profit), 2) + ")\n";
         }
         if(slave_pos_details == "") slave_pos_details = "   └ (Tidak ada posisi aktif)\n";

         double net_fl = total_profit + (m_slave_online ? m_slave_profit : 0.0);
         string sign = (net_fl >= 0) ? "+$" : "-$";

         string msg = "📊 <b>[LIVE DUAL-MT5 BONUS HEDGING]</b>\n" +
            "────────────────────────────\n" +
            "👑 <b>MASTER (" + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + ")</b>:\n" +
            "   • Equity / Bal : $" + DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY), 2) + " / $" + DoubleToString(balance, 2) + "\n" +
            "   • Margin Level : " + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_LEVEL), 1) + "% (Free: $" + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_FREE), 2) + ")\n" +
            "   • Floating : $" + DoubleToString(total_profit, 2) + " (" + IntegerToString(total_positions) + " Layers)\n" +
            master_pos_details + "\n" +
            "🛡️ <b>SLAVE (" + IntegerToString(m_slave_login) + " - Bonus 20%)</b>:\n" +
            "   • Equity / Bal : $" + DoubleToString(m_slave_equity, 2) + " / $" + DoubleToString(m_slave_balance, 2) + "\n" +
            "   • Margin Level : " + DoubleToString(m_slave_margin_level, 1) + "% (Free: $" + DoubleToString(m_slave_free_margin, 2) + ")\n" +
            "   • Floating : $" + DoubleToString(m_slave_profit, 2) + " (" + IntegerToString(m_slave_pos_count) + " Hedges)\n" +
            slave_pos_details +
            "────────────────────────────\n" +
            "🎯 <b>NET COMBINED : " + sign + DoubleToString(MathAbs(net_fl), 2) + "</b>\n" +
            "🎯 <b>TARGET PLUS : +$" + DoubleToString(basket_tp, 2) + "</b>";

         SendTelegramMessage(msg);
      }
   }
}

//+------------------------------------------------------------------+
//| URL Encode Helper                                                |
//+------------------------------------------------------------------+
string UrlEncode(string text)
{
   string result = "";
   uchar bytes[];
   StringToCharArray(text, bytes, 0, WHOLE_ARRAY, CP_UTF8);
   int len = ArraySize(bytes) - 1; // exclude null terminator

   for(int i = 0; i < len; i++)
   {
      uchar c = bytes[i];
      if((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
         c == '-' || c == '_' || c == '.' || c == '~')
      {
         result += CharToString(c);
      }
      else if(c == ' ')
      {
         result += "+";
      }
      else
      {
         result += StringFormat("%%%02X", c);
      }
   }
   return result;
}

//+------------------------------------------------------------------+
//| Helper: Send Message to Telegram API via HTTP POST               |
//+------------------------------------------------------------------+
void SendTelegramMessage(string raw_message)
{
   if(!InpEnableTelegram || StringLen(InpTelegramBotToken) == 0 || StringLen(InpTelegramChatID) == 0) return;

   string url     = "https://api.telegram.org/bot" + InpTelegramBotToken + "/sendMessage";
   string headers = "Content-Type: application/x-www-form-urlencoded\r\n";
   string payload = "chat_id=" + InpTelegramChatID + "&parse_mode=HTML&text=" + UrlEncode(raw_message);

   char post_data[], result[];
   string result_headers;
   StringToCharArray(payload, post_data, 0, WHOLE_ARRAY, CP_UTF8);
   ArrayResize(post_data, ArraySize(post_data) - 1); // remove null terminator

   ResetLastError();
   int http_code = WebRequest("POST", url, headers, 1000, post_data, result, result_headers);

   m_last_telegram_time = TimeCurrent(); // Update timestamp immediately to prevent tight retry loops

   if(http_code == 200)
   {
      Print("📱 [TELEGRAM SUCCESS] Laporan status berhasil terkirim ke Telegram!");
   }
   else
   {
      int err = GetLastError();
      Print("⚠️ [TELEGRAM FAILED] HTTP Code: ", http_code, " | Error Code: ", err);
      if(err == 4014)
      {
         Print("👉 Solusi: Buka MT5 Tools -> Options -> Expert Advisors -> Centang 'Allow WebRequest' dan tambahkan 'https://api.telegram.org'");
         // Mute telegram for 1 minute so it doesn't spam logs or block timer
         m_last_telegram_time = TimeCurrent() + 60;
      }
   }
}

//+------------------------------------------------------------------+
//| Helper: Stream Real-Time JSON Telemetry to Cloud Web API         |
//+------------------------------------------------------------------+
void SendWebTelemetry()
{
   if(!InpEnableWebDashboard || StringLen(InpWebDashboardUrl) == 0) return;
   if(TimeCurrent() - m_last_web_time < InpWebIntervalSec) return;
   m_last_web_time = TimeCurrent();

   int total_positions = 0;
   double total_profit = 0.0;
   string pairs_json = "";

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0
         && (StringCompare(PositionGetString(POSITION_SYMBOL), m_symbol, false) == 0 || StringCompare(PositionGetString(POSITION_SYMBOL), _Symbol, false) == 0)
         && PositionGetInteger(POSITION_MAGIC) == (long)InpMagic)
      {
         total_positions++;
         double p_prof = PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
         total_profit += p_prof;

         // Find matching slave position
         string expected_comment = "CT#" + IntegerToString(ticket);
         int s_idx = -1;
         for(int s = 0; s < m_slave_pos_count; s++)
         {
            if(StringFind(m_slave_positions[s].comment, expected_comment) >= 0)
            {
               s_idx = s;
               break;
            }
         }

         double s_prof = (s_idx >= 0) ? m_slave_positions[s_idx].profit : 0.0;
         double net_p  = p_prof + s_prof;
         ulong  s_t    = (s_idx >= 0) ? m_slave_positions[s_idx].ticket : 0;
         double s_v    = (s_idx >= 0) ? m_slave_positions[s_idx].volume : 0.0;
         double s_p    = (s_idx >= 0) ? m_slave_positions[s_idx].price_open : 0.0;

         if(pairs_json != "") pairs_json += ",";
         pairs_json += "{\"master_ticket\":" + IntegerToString(ticket) +
                       ",\"master_type\":\"" + ((PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_SELL) ? "SELL" : "BUY") + "\"" +
                       ",\"master_vol\":" + DoubleToString(PositionGetDouble(POSITION_VOLUME), 2) +
                       ",\"master_price\":" + DoubleToString(PositionGetDouble(POSITION_PRICE_OPEN), 2) +
                       ",\"master_profit\":" + DoubleToString(p_prof, 2) +
                       ",\"slave_ticket\":" + IntegerToString(s_t) +
                       ",\"slave_type\":\"" + ((s_idx >= 0 && m_slave_positions[s_idx].type == 1) ? "SELL" : "BUY") + "\"" +
                       ",\"slave_vol\":" + DoubleToString(s_v, 2) +
                       ",\"slave_price\":" + DoubleToString(s_p, 2) +
                       ",\"slave_profit\":" + DoubleToString(s_prof, 2) +
                       ",\"net_profit\":" + DoubleToString(net_p, 2) + "}";
      }
   }

   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double net_fl  = total_profit + (m_slave_online ? m_slave_profit : 0.0);
   double basket_tp = (InpInitialLot / 0.10) * 31.74;

   string payload = "{\"login\":" + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) +
                    ",\"symbol\":\"" + m_symbol + "\"" +
                    ",\"net_floating\":" + DoubleToString(net_fl, 2) +
                    ",\"target_tp\":" + DoubleToString(basket_tp, 2) +
                    ",\"master\":{\"login\":" + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) +
                                 ",\"equity\":" + DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY), 2) +
                                 ",\"balance\":" + DoubleToString(balance, 2) +
                                 ",\"free_margin\":" + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_FREE), 2) +
                                 ",\"margin_level\":" + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_LEVEL), 2) +
                                 ",\"profit\":" + DoubleToString(total_profit, 2) +
                                 ",\"count\":" + IntegerToString(total_positions) + "}" +
                    ",\"slave\":{\"login\":" + IntegerToString(m_slave_login) +
                                ",\"equity\":" + DoubleToString(m_slave_equity, 2) +
                                ",\"balance\":" + DoubleToString(m_slave_balance, 2) +
                                ",\"free_margin\":" + DoubleToString(m_slave_free_margin, 2) +
                                ",\"margin_level\":" + DoubleToString(m_slave_margin_level, 2) +
                                ",\"profit\":" + DoubleToString(m_slave_profit, 2) +
                                ",\"count\":" + IntegerToString(m_slave_pos_count) + "}" +
                    ",\"pairs\":[" + pairs_json + "]}";

   string headers = "Content-Type: application/json\r\n";
   char post_data[], result[];
   string result_headers;
   StringToCharArray(payload, post_data, 0, WHOLE_ARRAY, CP_UTF8);
   ArrayResize(post_data, ArraySize(post_data) - 1);

   ResetLastError();
   WebRequest("POST", InpWebDashboardUrl, headers, 1000, post_data, result, result_headers);
}

